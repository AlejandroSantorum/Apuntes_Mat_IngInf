package padsof;

/**
 * 
 * @author Alejandro Santorum y David Cabornero
 * This enumeration allows to specific the type of offer: short or long.
 *
 */
public enum OfferType {
	SHORT,
	LONG;
}
