Authors: Alejandro Santorum & David Cabornero
G02
Date: 07-05-2018

MANAGER KEYS:
	--> UserID: admin
	--> Password: admin

YOU CAN TEST THE GUI USING THE TEST PROVIDED: "GUI_InitialTest" placed in the package "TestingGUI".