var searchData=
[
  ['handler_5fsigusr1_5fbettor',['handler_SIGUSR1_bettor',['../proyecto_8c.html#a4a9eb9635b640723c989b595ae2563b7',1,'proyecto.c']]],
  ['handler_5fsigusr2',['handler_SIGUSR2',['../proyecto_8c.html#ad74373062149d2394167150b79a4dca9',1,'proyecto.c']]],
  ['horse',['horse',['../proyecto_8c.html#afc31db7de432d57007b0b9b3c518f405',1,'proyecto.c']]],
  ['horse_5fbet',['horse_bet',['../structmarket__rates__struct.html#a364e28430ed23ff65270f5124d94f932',1,'market_rates_struct']]],
  ['horse_5fid',['horse_id',['../structmsgbuf.html#a2d569f43a4859884c21c9ce8f1408eeb',1,'msgbuf']]],
  ['horse_5frate',['horse_rate',['../structmarket__rates__struct.html#ad3c6f2f118a4c411a8035256851d141a',1,'market_rates_struct']]],
  ['horses_5fdone',['horses_done',['../structrace__control__struct.html#a86354e834c5267f502b144c10cf45570',1,'race_control_struct']]]
];
