var searchData=
[
  ['betting_5fmanager_5fprocess',['betting_manager_process',['../proyecto_8c.html#ad86d0002bad6dc92d598b9dc1dc158e7',1,'proyecto.c']]],
  ['bettor_5fprocess',['bettor_process',['../proyecto_8c.html#a1c41f50bb3c770e73fc5d8cea3e96135',1,'proyecto.c']]],
  ['borrar_5fsemaforo',['Borrar_Semaforo',['../semaforos_8c.html#a731339337960a681efa435a10f12c312',1,'Borrar_Semaforo(int semid):&#160;semaforos.c'],['../semaforos_8h.html#a731339337960a681efa435a10f12c312',1,'Borrar_Semaforo(int semid):&#160;semaforos.c']]]
];
