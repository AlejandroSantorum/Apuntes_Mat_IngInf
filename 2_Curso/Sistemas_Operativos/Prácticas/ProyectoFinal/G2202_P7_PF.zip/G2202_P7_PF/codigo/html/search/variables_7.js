var searchData=
[
  ['n_5fhorses',['n_horses',['../proyecto_8c.html#a71cce9a5c473ee9da7abc2fa84010c30',1,'proyecto.c']]],
  ['name',['name',['../structmsgbuf.html#a72921f6ad2d6985d78d0e0fd1ae00774',1,'msgbuf']]]
];
