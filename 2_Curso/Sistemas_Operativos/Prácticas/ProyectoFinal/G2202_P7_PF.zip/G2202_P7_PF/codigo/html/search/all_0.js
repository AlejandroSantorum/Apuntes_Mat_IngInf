var searchData=
[
  ['aleat_5fnum',['aleat_num',['../proyecto_8c.html#a423be02d237888f767b6d107096c10f4',1,'proyecto.c']]]
];
