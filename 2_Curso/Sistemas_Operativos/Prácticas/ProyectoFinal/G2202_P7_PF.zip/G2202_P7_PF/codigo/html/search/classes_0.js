var searchData=
[
  ['market_5frates_5fstruct',['market_rates_struct',['../structmarket__rates__struct.html',1,'']]],
  ['msgbuf',['msgbuf',['../structmsgbuf.html',1,'']]]
];
