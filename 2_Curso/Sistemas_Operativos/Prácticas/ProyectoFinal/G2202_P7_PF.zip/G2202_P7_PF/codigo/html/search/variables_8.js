var searchData=
[
  ['pids',['pids',['../proyecto_8c.html#ae2dbd09bc5d807d7e639d9b4ada71a7e',1,'proyecto.c']]],
  ['position',['position',['../structmsgbuf.html#a0a654069b1868c3be58115550ed078fa',1,'msgbuf::position()'],['../structrace__control__struct.html#aa99101cd69a20dcdd9f3322cf272d434',1,'race_control_struct::position()']]]
];
