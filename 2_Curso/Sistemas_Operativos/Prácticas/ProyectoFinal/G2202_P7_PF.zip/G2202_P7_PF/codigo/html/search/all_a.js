var searchData=
[
  ['n_5fargs',['N_ARGS',['../proyecto_8c.html#a45427030a543a1fe5b6a6ad24b0415a5',1,'proyecto.c']]],
  ['n_5fbest_5fbettor',['N_BEST_BETTOR',['../proyecto_8c.html#a6553be7790241bf88c873cc1549487e1',1,'proyecto.c']]],
  ['n_5fhorses',['n_horses',['../proyecto_8c.html#a71cce9a5c473ee9da7abc2fa84010c30',1,'proyecto.c']]],
  ['name',['name',['../structmsgbuf.html#a72921f6ad2d6985d78d0e0fd1ae00774',1,'msgbuf']]],
  ['name_5fsize',['NAME_SIZE',['../proyecto_8c.html#a834e9a379307f869a10f4da078be5786',1,'proyecto.c']]],
  ['normal',['NORMAL',['../proyecto_8c.html#a1291f416b069313021b519eea62d5bf1',1,'proyecto.c']]]
];
