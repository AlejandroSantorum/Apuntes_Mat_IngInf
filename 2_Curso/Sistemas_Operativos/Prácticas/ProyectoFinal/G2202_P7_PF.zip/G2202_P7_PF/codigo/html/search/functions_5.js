var searchData=
[
  ['handler_5fsigusr1_5fbettor',['handler_SIGUSR1_bettor',['../proyecto_8c.html#a4a9eb9635b640723c989b595ae2563b7',1,'proyecto.c']]],
  ['handler_5fsigusr2',['handler_SIGUSR2',['../proyecto_8c.html#ad74373062149d2394167150b79a4dca9',1,'proyecto.c']]],
  ['horse',['horse',['../proyecto_8c.html#afc31db7de432d57007b0b9b3c518f405',1,'proyecto.c']]]
];
