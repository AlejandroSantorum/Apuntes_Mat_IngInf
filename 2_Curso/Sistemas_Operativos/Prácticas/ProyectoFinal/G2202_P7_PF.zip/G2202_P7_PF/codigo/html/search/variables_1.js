var searchData=
[
  ['current_5fbox',['current_box',['../structrace__control__struct.html#a739b57a39c850d267de155e8c866bd23',1,'race_control_struct']]]
];
