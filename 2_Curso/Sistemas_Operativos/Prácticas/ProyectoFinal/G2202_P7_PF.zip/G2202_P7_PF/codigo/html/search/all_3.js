var searchData=
[
  ['displayer_5fprocess',['displayer_process',['../proyecto_8c.html#a8c10e09a164a4c558b48b6c6d30cf70b',1,'proyecto.c']]],
  ['down_5fsemaforo',['Down_Semaforo',['../semaforos_8c.html#a883244cd3b83c42cda23687da1b63369',1,'Down_Semaforo(int id, int num_sem, int undo):&#160;semaforos.c'],['../semaforos_8h.html#a883244cd3b83c42cda23687da1b63369',1,'Down_Semaforo(int id, int num_sem, int undo):&#160;semaforos.c']]],
  ['downmultiple_5fsemaforo',['DownMultiple_Semaforo',['../semaforos_8c.html#ab375ebfc38acbdced46e062a689d5fad',1,'DownMultiple_Semaforo(int id, int size, int undo, int *active):&#160;semaforos.c'],['../semaforos_8h.html#ab375ebfc38acbdced46e062a689d5fad',1,'DownMultiple_Semaforo(int id, int size, int undo, int *active):&#160;semaforos.c']]]
];
