var searchData=
[
  ['info',['info',['../structmsgbuf.html#ad43d12674488c373d8fb69efed53c3cc',1,'msgbuf']]]
];
