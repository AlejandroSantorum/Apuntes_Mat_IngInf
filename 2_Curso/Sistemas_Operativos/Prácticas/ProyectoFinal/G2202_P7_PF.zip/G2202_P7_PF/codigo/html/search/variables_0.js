var searchData=
[
  ['bet',['bet',['../structmsgbuf.html#a39278db78542cbe8cf2df77ac5b8b080',1,'msgbuf']]],
  ['betting',['betting',['../structmsgbuf.html#a1337d4cd36a0fa762c15244c00853381',1,'msgbuf']]],
  ['bettor_5fid',['bettor_id',['../structmsgbuf.html#a4d6daa3e4bf410b275b596b1e6828110',1,'msgbuf']]]
];
