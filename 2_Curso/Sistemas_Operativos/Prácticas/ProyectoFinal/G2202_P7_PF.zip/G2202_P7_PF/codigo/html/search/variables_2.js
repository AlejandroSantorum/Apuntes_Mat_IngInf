var searchData=
[
  ['flag_5fbettor',['flag_bettor',['../proyecto_8c.html#ab64e560b3425405da700479853245853',1,'proyecto.c']]]
];
