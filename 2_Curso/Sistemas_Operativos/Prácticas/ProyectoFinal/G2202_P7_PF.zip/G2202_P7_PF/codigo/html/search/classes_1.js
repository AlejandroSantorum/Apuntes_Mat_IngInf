var searchData=
[
  ['race_5fcontrol_5fstruct',['race_control_struct',['../structrace__control__struct.html',1,'']]]
];
