var searchData=
[
  ['path',['PATH',['../proyecto_8c.html#ab0139008fdda107456f13f837872b410',1,'proyecto.c']]],
  ['proc_5fbettor',['PROC_BETTOR',['../proyecto_8c.html#acb4a682f0662a1fc810539b0e24797cc',1,'proyecto.c']]],
  ['proc_5fdisplayer',['PROC_DISPLAYER',['../proyecto_8c.html#ad798c34a41dfac0cc34f1c71c9278476',1,'proyecto.c']]],
  ['proc_5fmanager',['PROC_MANAGER',['../proyecto_8c.html#a39ce4c57ee1cd38a8230f70193b506d3',1,'proyecto.c']]]
];
