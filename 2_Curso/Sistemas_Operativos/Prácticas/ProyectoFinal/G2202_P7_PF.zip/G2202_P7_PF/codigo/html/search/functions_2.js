var searchData=
[
  ['calculate_5fbet_5fresults',['calculate_bet_results',['../proyecto_8c.html#a25a03578340ad5ea8ef8689220b6ec2c',1,'proyecto.c']]],
  ['checked',['checked',['../proyecto_8c.html#a4f2e3020d3fd9eefc3742496fd1d1112',1,'proyecto.c']]],
  ['classification',['classification',['../proyecto_8c.html#a6ac7cf6dff95cd711b8bd73de83146c1',1,'proyecto.c']]],
  ['crear_5fsemaforo',['Crear_Semaforo',['../semaforos_8c.html#a16b16dd895b5f4cbe48f1ac8977e8b35',1,'Crear_Semaforo(key_t key, int size, int *semid):&#160;semaforos.c'],['../semaforos_8h.html#a16b16dd895b5f4cbe48f1ac8977e8b35',1,'Crear_Semaforo(key_t key, int size, int *semid):&#160;semaforos.c']]]
];
