var searchData=
[
  ['print_5fbest_5fbettors',['print_best_bettors',['../proyecto_8c.html#aedefd2b2f11c534044047a0213408a29',1,'proyecto.c']]]
];
