var searchData=
[
  ['total',['total',['../structmarket__rates__struct.html#afabd309263178532df483c3f56acb586',1,'market_rates_struct']]]
];
