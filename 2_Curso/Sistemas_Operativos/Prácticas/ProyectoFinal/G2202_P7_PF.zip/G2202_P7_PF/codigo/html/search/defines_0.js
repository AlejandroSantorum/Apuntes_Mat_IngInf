var searchData=
[
  ['betfile',['BETFILE',['../proyecto_8c.html#aae41b9fee1a9f666fa16a88e24309186',1,'proyecto.c']]],
  ['bettorfile',['BETTORFILE',['../proyecto_8c.html#a4b646acb77bd65ffb169af5ad1407a76',1,'proyecto.c']]],
  ['buffer_5fsize',['BUFFER_SIZE',['../proyecto_8c.html#a6b20d41d6252e9871430c242cb1a56e7',1,'proyecto.c']]]
];
