var searchData=
[
  ['bet',['bet',['../structmsgbuf.html#a39278db78542cbe8cf2df77ac5b8b080',1,'msgbuf']]],
  ['betfile',['BETFILE',['../proyecto_8c.html#aae41b9fee1a9f666fa16a88e24309186',1,'proyecto.c']]],
  ['betting',['betting',['../structmsgbuf.html#a1337d4cd36a0fa762c15244c00853381',1,'msgbuf']]],
  ['betting_5fmanager_5fprocess',['betting_manager_process',['../proyecto_8c.html#ad86d0002bad6dc92d598b9dc1dc158e7',1,'proyecto.c']]],
  ['bettor_5fid',['bettor_id',['../structmsgbuf.html#a4d6daa3e4bf410b275b596b1e6828110',1,'msgbuf']]],
  ['bettor_5fprocess',['bettor_process',['../proyecto_8c.html#a1c41f50bb3c770e73fc5d8cea3e96135',1,'proyecto.c']]],
  ['bettorfile',['BETTORFILE',['../proyecto_8c.html#a4b646acb77bd65ffb169af5ad1407a76',1,'proyecto.c']]],
  ['borrar_5fsemaforo',['Borrar_Semaforo',['../semaforos_8c.html#a731339337960a681efa435a10f12c312',1,'Borrar_Semaforo(int semid):&#160;semaforos.c'],['../semaforos_8h.html#a731339337960a681efa435a10f12c312',1,'Borrar_Semaforo(int semid):&#160;semaforos.c']]],
  ['buffer_5fsize',['BUFFER_SIZE',['../proyecto_8c.html#a6b20d41d6252e9871430c242cb1a56e7',1,'proyecto.c']]]
];
