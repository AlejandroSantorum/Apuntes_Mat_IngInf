var searchData=
[
  ['race_5fcontrol',['race_control',['../proyecto_8c.html#a6dc9be99884e82ceb7b58a5de4613f70',1,'proyecto.c']]]
];
