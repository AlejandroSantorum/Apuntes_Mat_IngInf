var searchData=
[
  ['market_5frates',['market_rates',['../proyecto_8c.html#ab77451f408925891ab0ac04c0d901131',1,'proyecto.c']]],
  ['mtype',['mtype',['../structmsgbuf.html#a12a4780abaa96553f2ebf5fafeb58360',1,'msgbuf']]]
];
