var searchData=
[
  ['path',['PATH',['../proyecto_8c.html#ab0139008fdda107456f13f837872b410',1,'proyecto.c']]],
  ['pids',['pids',['../proyecto_8c.html#ae2dbd09bc5d807d7e639d9b4ada71a7e',1,'proyecto.c']]],
  ['position',['position',['../structmsgbuf.html#a0a654069b1868c3be58115550ed078fa',1,'msgbuf::position()'],['../structrace__control__struct.html#aa99101cd69a20dcdd9f3322cf272d434',1,'race_control_struct::position()']]],
  ['print_5fbest_5fbettors',['print_best_bettors',['../proyecto_8c.html#aedefd2b2f11c534044047a0213408a29',1,'proyecto.c']]],
  ['proc_5fbettor',['PROC_BETTOR',['../proyecto_8c.html#acb4a682f0662a1fc810539b0e24797cc',1,'proyecto.c']]],
  ['proc_5fdisplayer',['PROC_DISPLAYER',['../proyecto_8c.html#ad798c34a41dfac0cc34f1c71c9278476',1,'proyecto.c']]],
  ['proc_5fmanager',['PROC_MANAGER',['../proyecto_8c.html#a39ce4c57ee1cd38a8230f70193b506d3',1,'proyecto.c']]],
  ['proyecto_2ec',['proyecto.c',['../proyecto_8c.html',1,'']]]
];
