var searchData=
[
  ['seconds',['SECONDS',['../proyecto_8c.html#a48fcf4f2eeef6769d588168d4ac2ab0e',1,'proyecto.c']]],
  ['sem_5fsize',['SEM_SIZE',['../proyecto_8c.html#ad2d98a7d31786f8332b2aaf8525bb1e2',1,'proyecto.c']]]
];
