var searchData=
[
  ['race_5fcontrol',['race_control',['../proyecto_8c.html#a6dc9be99884e82ceb7b58a5de4613f70',1,'proyecto.c']]],
  ['race_5fcontrol_5fstruct',['race_control_struct',['../structrace__control__struct.html',1,'']]],
  ['racecontrol_5fsem',['RACECONTROL_SEM',['../proyecto_8c.html#a549b501dcbeadb15771f3172449d6b2e',1,'proyecto.c']]]
];
