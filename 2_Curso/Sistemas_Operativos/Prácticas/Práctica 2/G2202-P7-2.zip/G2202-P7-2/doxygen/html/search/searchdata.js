var indexSectionsWithContent =
{
  0: "bcdehinosu",
  1: "es",
  2: "bcdhiu",
  3: "eno"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Macros"
};

