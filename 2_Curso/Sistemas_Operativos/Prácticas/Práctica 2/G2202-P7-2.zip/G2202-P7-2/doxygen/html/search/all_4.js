var searchData=
[
  ['handler_5fsigterm',['handler_SIGTERM',['../ejercicio6b_8c.html#aaf4e4635ab40745568d100c91f0d5a19',1,'ejercicio6b.c']]],
  ['handler_5fsigusr1',['handler_SIGUSR1',['../ejercicio4_8c.html#affae6eb1392c68ed64ab02cd348429d2',1,'ejercicio4.c']]]
];
