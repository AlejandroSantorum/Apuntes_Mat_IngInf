var searchData=
[
  ['n_5fchilds',['N_CHILDS',['../ejercicio2_8c.html#a469b1ab8d3ecbd62178c442e0d19c200',1,'ejercicio2.c']]],
  ['n_5fprint',['N_PRINT',['../ejercicio4_8c.html#a1eae4448563ec6ad91f74fc8e8ba228d',1,'ejercicio4.c']]],
  ['num',['NUM',['../ejercicio6a_8c.html#aaf0952059602752258dccaa015d7b54a',1,'NUM():&#160;ejercicio6a.c'],['../ejercicio6b_8c.html#aaf0952059602752258dccaa015d7b54a',1,'NUM():&#160;ejercicio6b.c']]]
];
