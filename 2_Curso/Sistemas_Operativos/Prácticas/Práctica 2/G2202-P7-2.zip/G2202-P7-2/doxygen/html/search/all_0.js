var searchData=
[
  ['borrar_5fsemaforo',['Borrar_Semaforo',['../semaforos_8c.html#a731339337960a681efa435a10f12c312',1,'Borrar_Semaforo(int semid):&#160;semaforos.c'],['../semaforos_8h.html#a731339337960a681efa435a10f12c312',1,'Borrar_Semaforo(int semid):&#160;semaforos.c']]]
];
