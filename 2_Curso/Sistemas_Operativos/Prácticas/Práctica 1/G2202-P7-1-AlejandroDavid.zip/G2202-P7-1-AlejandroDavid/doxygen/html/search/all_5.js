var searchData=
[
  ['id',['id',['../structArgum.html#a1e19639236d672db337655913280c502',1,'Argum']]],
  ['is_5fprime',['is_prime',['../ejercicio12a_8c.html#ad6740255386952216cb75d813243a3ea',1,'is_prime(int n):&#160;ejercicio12a.c'],['../ejercicio12b_8c.html#ad6740255386952216cb75d813243a3ea',1,'is_prime(int n):&#160;ejercicio12b.c']]]
];
