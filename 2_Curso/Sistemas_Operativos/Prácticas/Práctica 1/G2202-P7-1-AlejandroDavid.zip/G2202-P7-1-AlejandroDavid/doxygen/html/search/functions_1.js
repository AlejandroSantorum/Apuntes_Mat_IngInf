var searchData=
[
  ['calculate_5fprimes',['calculate_primes',['../ejercicio12a_8c.html#aca3b2affe916a5464b035bde74fd4fae',1,'calculate_primes(int n_primes):&#160;ejercicio12a.c'],['../ejercicio12b_8c.html#a1996c5f0c98019293b7cfad2861f4547',1,'calculate_primes(void *arg):&#160;ejercicio12b.c']]]
];
