var searchData=
[
  ['n',['n',['../structStructure.html#ae554951bcd1248a08201a48ce50b81c4',1,'Structure']]],
  ['n_5fchilds',['N_CHILDS',['../ejercicio12a_8c.html#a469b1ab8d3ecbd62178c442e0d19c200',1,'N_CHILDS():&#160;ejercicio12a.c'],['../ejercicio9_8c.html#a469b1ab8d3ecbd62178c442e0d19c200',1,'N_CHILDS():&#160;ejercicio9.c']]],
  ['n_5fthreads',['N_THREADS',['../ejercicio12b_8c.html#ab60b5074c740fd36061f48f90d1a0b21',1,'ejercicio12b.c']]]
];
