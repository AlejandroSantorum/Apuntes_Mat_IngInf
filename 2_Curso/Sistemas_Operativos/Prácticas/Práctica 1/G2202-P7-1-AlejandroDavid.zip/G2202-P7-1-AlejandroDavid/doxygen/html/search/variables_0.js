var searchData=
[
  ['dim',['dim',['../structArgum.html#a69c560b91efcd6709b891e9a7fd204bd',1,'Argum']]]
];
