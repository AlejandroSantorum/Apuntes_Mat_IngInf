var searchData=
[
  ['is_5fprime',['is_prime',['../ejercicio12a_8c.html#ad6740255386952216cb75d813243a3ea',1,'is_prime(int n):&#160;ejercicio12a.c'],['../ejercicio12b_8c.html#ad6740255386952216cb75d813243a3ea',1,'is_prime(int n):&#160;ejercicio12b.c']]]
];
