var searchData=
[
  ['matrix',['matrix',['../structArgum.html#a5e62bf7d3af611b48cdeed5decdf47be',1,'Argum']]]
];
