var searchData=
[
  ['matrix',['matrix',['../structArgum.html#a5e62bf7d3af611b48cdeed5decdf47be',1,'Argum']]],
  ['mult_5fmatrix',['mult_matrix',['../ejercicio13_8c.html#a4dd6e3f428ac001b95d386b8045a2db9',1,'ejercicio13.c']]]
];
