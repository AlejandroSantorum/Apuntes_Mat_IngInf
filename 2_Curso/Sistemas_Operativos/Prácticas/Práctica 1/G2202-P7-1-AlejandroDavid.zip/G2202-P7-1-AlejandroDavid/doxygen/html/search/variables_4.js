var searchData=
[
  ['pos1',['pos1',['../structArgum.html#a6ba39122df5e87923c854fdb415b37af',1,'Argum']]],
  ['pos2',['pos2',['../structArgum.html#a69aaf9b57d62f8704a7f83afaca5d361',1,'Argum']]]
];
