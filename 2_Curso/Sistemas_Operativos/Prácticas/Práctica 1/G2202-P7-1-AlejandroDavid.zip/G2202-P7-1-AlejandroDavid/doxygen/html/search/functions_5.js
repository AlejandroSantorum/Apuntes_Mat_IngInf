var searchData=
[
  ['split_5ffirst',['split_first',['../ejercicio9_8c.html#a4aa006d6fead344c31cadac2d1292a8e',1,'ejercicio9.c']]],
  ['split_5fsecond',['split_second',['../ejercicio9_8c.html#a6b950f9c2c30c4e1c810b97ee01f141b',1,'ejercicio9.c']]]
];
