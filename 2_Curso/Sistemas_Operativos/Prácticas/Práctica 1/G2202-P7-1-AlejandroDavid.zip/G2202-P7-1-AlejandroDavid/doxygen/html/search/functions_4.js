var searchData=
[
  ['mult_5fmatrix',['mult_matrix',['../ejercicio13_8c.html#a4dd6e3f428ac001b95d386b8045a2db9',1,'ejercicio13.c']]]
];
