var searchData=
[
  ['tentothenine',['TENTOTHENINE',['../ejercicio12a_8c.html#a1dc0370947cd4d4485a36ad37de15139',1,'TENTOTHENINE():&#160;ejercicio12a.c'],['../ejercicio12b_8c.html#a1dc0370947cd4d4485a36ad37de15139',1,'TENTOTHENINE():&#160;ejercicio12b.c']]]
];
