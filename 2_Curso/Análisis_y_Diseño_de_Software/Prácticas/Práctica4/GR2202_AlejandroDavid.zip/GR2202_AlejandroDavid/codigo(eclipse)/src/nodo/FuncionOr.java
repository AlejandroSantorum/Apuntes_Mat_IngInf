package nodo;

import java.util.*;

import excepciones.*;
/**
 * 
 * @author David Cabornero y Alejandro Santorum
 *Esta clase permite realizar la operacion or a booleanos
 */
public class FuncionOr extends Funcion{
	/**
     * Constructor de FuncionNor
     * @param simbolo Simbolo que va a representar la operacion or
     * @param maxDescendientes Maximo numero de descendientes permitidos
     */
    public FuncionOr(String simbolo, int maxDescendientes){
        super(simbolo, maxDescendientes);
    }
    /**
     * Permite calcular el resultado logico de la operacion or
     */
    public double calcular(){
        ArrayList<INodo> descendientes = this.getDescendientes();
        double calculo = 0.0;
        
        for(INodo n: descendientes){
            calculo = FuncionOr.or(calculo, n.calcular());
        }
        return calculo;
    }
    /**
     * Permite copiar la funcion, al igual que todos sus hijos
     */
    public INodo copy() throws MaximosDescendientesException{
        FuncionOr fo = new FuncionOr(this.getRaiz(), this.getMaxDescendientes());
        
        ArrayList<INodo> arrayDes = this.getDescendientes();
        
        if(arrayDes.size() > 0){
            for(INodo n: arrayDes){
                INodo nuevo = n.copy();
                fo.incluirDescendiente(nuevo);
            }
        }
        
        return fo;
    }
    
    /**
     * Realiza la operacion or sobre dos booleanos
     * @param op1 Primer booleano
     * @param op2 Segundo booleano
     * @return Resultado de la operacion (0 en caso de error)
     */
    private static double or(double op1, double op2){
        if(op1==1.0 || op2==1.0) return 1.0;
        else return 0.0;
    }
}