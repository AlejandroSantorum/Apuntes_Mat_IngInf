package excepciones;

/**
 * 
 * @author David Cabornero y Alejandro Santorum
 * Esta excepcion sera utilizada cuando, al crear un individuo, la profundidad dada
 * no sea coherente con la lista de terminales y funciones recibidas.
 *
 */
public class ProfundidadInvalidaException extends Exception{
	
	/**
	 * Constructor de la excepcion ProfundidadInvalidaException
	 * @param m Mensaje enviado a la consola
	 */
	public ProfundidadInvalidaException(String m) {
		super(m);
	}

}