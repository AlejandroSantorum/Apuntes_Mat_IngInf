package nodo;

import java.util.*;

import excepciones.*;
/**
 * 
 * @author David Cabornero y Alejandro Santorum
 *Esta funcion permite restar sus nodos hijos, restando todos ellos al primero
 */
public class FuncionResta extends Funcion{
    /**
     * Constructor de FuncionResta
     * @param simbolo Simbolo asociado a la funcion resta
     * @param maxDescendientes NUmero maximo de descendientes admitido
     */
    public FuncionResta(String simbolo, int maxDescendientes){
        super(simbolo, maxDescendientes);
    }
    
    /**
     * Devuelve el valor resultante a restar todos sus nodos al primero
     */
    public double calcular(){
        ArrayList<INodo> descendientes = this.getDescendientes();
        double calculo = descendientes.get(0).calcular();
        
        for(int i=1; i<descendientes.size(); i++){
            calculo -= descendientes.get(i).calcular();
        }
        return calculo;
    }
    
    /**
     * Permite copiar la funcion, al igual que todos sus hijos
     */
    public INodo copy() throws MaximosDescendientesException{
        FuncionResta fr = new FuncionResta(this.getRaiz(), this.getMaxDescendientes());
        
        ArrayList<INodo> arrayDes = this.getDescendientes();
        
        if(arrayDes.size() > 0){
            for(INodo n: arrayDes){
                INodo nuevo = n.copy();
                fr.incluirDescendiente(nuevo);
            }
        }
        
        return fr;
    }
    
}