package nodo;

import java.util.*;

import excepciones.*;
/**
 * 
 * @author David Cabornero y Alejandro Santorum
 *Esta funcion permite crear una funcion que multiplique sus nodos
 */
public class FuncionMultiplicacion extends Funcion{
    /**
     * Constructor de la clase multiplicacion
     * @param simbolo Simbolo asociado a la funcion
     * @param maxDescendientes Maximo de descendientes permitidos
     */
    public FuncionMultiplicacion(String simbolo, int maxDescendientes){
        super(simbolo, maxDescendientes);
    }
    /**
     * Permite calcular el producto de sus nodos hijo
     * @return Resultado del producto
     */
    public double calcular(){
        ArrayList<INodo> descendientes = this.getDescendientes();
        double calculo = 1;
        
        for(INodo n: descendientes){
            calculo *= n.calcular();
        }
        return calculo;
    }
    
    
    /**
     * Permite crear una copia del terminal
     */
    public INodo copy() throws MaximosDescendientesException{
        FuncionMultiplicacion fm = new FuncionMultiplicacion(this.getRaiz(), this.getMaxDescendientes());
        
        ArrayList<INodo> arrayDes = this.getDescendientes();
        
        if(arrayDes.size() > 0){
            for(INodo n: arrayDes){
                INodo nuevo = n.copy();
                fm.incluirDescendiente(nuevo);
            }
        }
        
        return fm;
    }
}