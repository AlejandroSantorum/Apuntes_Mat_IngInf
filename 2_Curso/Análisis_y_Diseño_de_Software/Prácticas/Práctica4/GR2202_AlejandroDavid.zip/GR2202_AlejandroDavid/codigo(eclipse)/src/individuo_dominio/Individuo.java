package individuo_dominio;

import java.util.*;

import nodo.*;
import excepciones.*;
import algoritmo.*;

/**
 * 
 * @author David Cabornero y Alejandro Santorum
 *
 *	En esa funcion se definiran las funciones y atributos que debe poseer todo individuo
 *en el problema que nos incumbe.
 */
public class Individuo implements IIndividuo{
    private INodo raiz;
    private double fitness=-1;
    /**
	 * Devuelve el nodo raiz del individuo
	 * @return El nodo raiz del individuo
	 */
    public INodo getExpresion(){
        return raiz;
    }
    /**
     * Permite establecer el nodo raiz del individuo
     * @param expresion Nodo raiz establecido
     */
    public void setExpresion(INodo expresion){
        raiz = expresion;
    }
    /**
     * Esta funcion realiza las operaciones pertinentes para obtener el resultado de la union de los 
     * terminales y funciones definidos en nuestro individuo en forma de nodos de arbol.
     * @return La expresion resultante
     */
    public double calcularExpresion(){
        return this.raiz.calcular();
    }
    /**
     * Devuelve el numero de nodos que posee el individuo
     * @return Numero de nodos del individuo
     */
    public int getNumeroNodos(){
        return ((Nodo) this.raiz).getAllDescendientes().size();
    }
    /**
     * Esta funcion imprime la expresion resultante del individuo
     */
    public void writeIndividuo(){
        System.out.println(this.raiz);
    }
    /**
     * Este valor devuelve la calidad del individuo para la resolucion del problema
     * @return El fitness del individuo
     */
    public double getFitness(){
        return fitness;
    }
    /**
     * Permite establecer el fitness de un individuo
     * @param fitness Fitness que queremos dar al individuo
     */
    public void setFitness(double fitness){
        this.fitness = fitness;
    }
    /**
     * Esta funcion permite inicializar todos los ID de los nodos del individuo de forma ordenada.
     */
    public void etiquetaNodos(){
        ((Nodo) this.raiz).etiquetarDescendientes();
    }
    
    /**
     * Esta funcion permite crear un individuo aleatorio con ciertas cualidades
     * @param profundidad Profundidad del individuo
     * @param terminales Lista de terminales del individuo
     * @param funciones Lista de funciones del individuo
     * @throws ProfundidadInvalidaException La profundidad dada no coincide con las listas de terminales y funciones
     * @throws MaximosDescendientesException Se ha superado el maximo numero de descendientes de un nodo
     */
    public void crearIndividuoAleatorio(int profundidad, List<Terminal> terminales, List<Funcion> funciones) throws ProfundidadInvalidaException, MaximosDescendientesException{
        if(profundidad <= 1){
            throw new ProfundidadInvalidaException("crearIndividuoAleatorio: no se admite una profundidad menor o igual a uno");
        }
        
        if(profundidad==2){
            int max = terminales.size()-1;
            int ini = ((Nodo) this.raiz).getNumDescendientes();
            int total = ((Nodo) this.raiz).getMaxDescendientes();
            
            for(int i=ini; i<total; i++){
                int rand = PruebaCruce.aleat_num(0, max);
                Terminal term = terminales.get(rand);
                ((Nodo) this.raiz).incluirDescendiente((INodo) term);
            }
            return;
        }
        
        if(profundidad > 2){
            int max = funciones.size()-1;
            int ini = ((Nodo) this.raiz).getNumDescendientes();
            int total = ((Nodo) this.raiz).getMaxDescendientes();
            
            for(int i=ini; i<total; i++){
                int rand = PruebaCruce.aleat_num(0, max);
                Funcion func = funciones.get(rand);
                ((Nodo) this.raiz).incluirDescendiente((INodo) func);
            }
            
            ArrayList<INodo> hijos = ((Nodo) this.raiz).getDescendientes();
            
            for(INodo hijo: hijos){
                Individuo ind = new Individuo();
                ind.setExpresion(hijo);
                ind.crearIndividuoAleatorio(profundidad-1, terminales, funciones);
            }
        }
        return;
    }    
    
}