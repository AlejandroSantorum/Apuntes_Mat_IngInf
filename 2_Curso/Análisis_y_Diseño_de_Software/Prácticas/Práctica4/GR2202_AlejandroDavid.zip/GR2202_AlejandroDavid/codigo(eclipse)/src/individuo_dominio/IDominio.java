package individuo_dominio;

import java.io.*;
import java.util.*;

import nodo.*;
import excepciones.*;

/**
 * 
 * @author David Cabornero y Alejandro Santorum
 *	
 *	En esta interfaz estaran definidas las funciones que deben tener todos los dominios creados.
 */
public interface IDominio {
	/**
	 * Esta funcion define la lista de terminales del dominio.
	 * @param terminales Conjunto de terminales que vamos a incluir en el dominio
	 * @return Lista de terminales devuelta
	 */
    public List<Terminal> definirConjuntoTerminales(String... terminales); 
    /**
     * Esta funcion define la lista de funciones del dominio, donde se define cada 
     * maxArgumentos y cada simbolo respectivamente en los dos argumentos de la funcion
     * @param argumentos Array de argumentos que, respectivamente, va a admitir como
     * maximo cada funcion (array de maxDescendientes
     * @param funciones Conjunto de argumentos String que va a representar cada funcion del conjunto
     * respectivamente
     * @return Lista de funciones creadas
     * @throws ArgsDistintosFuncionesException El tamanio del array de maxArgumentos y el numero
     * de Strings pasadas es distinto.
     */
    public List<Funcion> definirConjuntoFunciones(int[] argumentos, String... funciones) throws ArgsDistintosFuncionesException;
    /**
     * Definimos los valores de prueba para nuestra aplicacion, definidos en el fichero, guardandolos
     * asi en atributos de nuestra clase.
     * @param ficheroDatos Fichero en el que estan incluidos nuestros datos
     * @throws FileNotFoundException Fichero no encontrado
     * @throws IOException Error al abrir el fichero
     */
    public void definirValoresPrueba(String ficheroDatos) throws FileNotFoundException, IOException;   
    /**
     * Esta funcion calcula un fitness de un cierto individuo, y lo imprime si queremos.
     * @param individuo Individuo del que se quiere hallar el fitness
     * @param flag Flag que, de ser distinta de 0, imprimira los valores en los que
     * se evalua al individuo, el resultado estimado de la evaluacion y el resultado real
     * @return El fitness resultante
     */
    public double calcularFitness(IIndividuo individuo, int flag); 
}
