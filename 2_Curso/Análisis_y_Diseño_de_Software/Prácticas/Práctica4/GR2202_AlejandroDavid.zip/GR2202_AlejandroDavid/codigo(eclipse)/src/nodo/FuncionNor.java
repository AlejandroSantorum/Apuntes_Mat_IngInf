package nodo;

import java.util.*;

import excepciones.*;
/**
 * 
 * @author David Cabornero y Alejandro Santorum
 *Esta clase permite realizar la operacion Nor a booleanos
 */
public class FuncionNor extends Funcion{
	/**
     * Constructor de FuncionNor
     * @param simbolo Simbolo que va a representar la operacion Nor
     * @param maxDescendientes Maximo numero de descendientes permitidos
     */
    public FuncionNor(String simbolo, int maxDescendientes){
        super(simbolo, maxDescendientes);
    }
    /**
     * Permite calcular el resultado logico de la operacion nor
     */
    public double calcular(){
        ArrayList<INodo> descendientes = this.getDescendientes();
        double calculo = 1;
        
        for(INodo n: descendientes){
            calculo = FuncionNor.or(calculo, n.calcular());
        }
        
        return FuncionNor.not(calculo);
    }
    /**
     * Permite copiar la funcion, al igual que todos sus hijos
     */
    public INodo copy() throws MaximosDescendientesException{
        FuncionNor fn = new FuncionNor(this.getRaiz(), this.getMaxDescendientes());
        
        ArrayList<INodo> arrayDes = this.getDescendientes();
        
        if(arrayDes.size() > 0){
            for(INodo n: arrayDes){
                INodo nuevo = n.copy();
                fn.incluirDescendiente(nuevo);
            }
        }
        
        return fn;
    }
    /**
     * Realiza la operacion or sobre dos booleanos
     * @param op1 Primer booleano
     * @param op2 Segundo booleano
     * @return Resultado de la operacion (0 en caso de error)
     */
    private static double or(double op1, double op2){
        if(op1==1.0 || op2==1.0) return 1.0;
        else return 0.0;
    }
    
    /**
     * Realiza la operacion not sobre un booleano
     * @param op Primer booleano
     * @return Resultado de la operacion (-1 en caso de error)
     */
    private static double not(double op){
        if(op == 1.0) return 0.0;
        else if(op == 0.0) return 1.0;
        else return -1.0;
    }
    
}