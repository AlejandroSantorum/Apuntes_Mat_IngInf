package nodo;


/**
 * 
 * @author David Cabornero y Alejandro Santorum
 *	
 *	En esta clase definiremos los atributos y funciones que debe poseer cualquier terminal.
 *Un terminal, recordemos que es un nodo que no opera sobre descendientes, sino que es una
 *experesion atomica.
 */
public abstract class Terminal extends Nodo{
    
	/**
	 * Constructor de la clase Terminal
	 * @param simbolo Simbolo que va a representar el terminal
	 */
    public Terminal(String simbolo){
        super(simbolo, 0);
    }
    
    /**
     * Devuelve el valor relativo al terminal
     * @return Valor del terminal
     */
    public abstract double calcular();
    
    /**
     * Permite copiar el nodo (en este caso no sus hijos, ya que no tiene)
     * @return Nodo copiado
     */
    public abstract INodo copy();
    
    /**
     * Devuelve una String con su expresion (en este caso sin tener en cuenta a hijos, dado
     * que una terminal no tiene.
     */
    public String toString(){
        return this.getRaiz();
    }
}