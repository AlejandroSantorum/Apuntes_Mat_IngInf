package individuo_dominio;

import java.util.*;

import nodo.*;
import excepciones.*;

/**
 * 
 * @author David Cabornero y Alejandro Santorum
 *
 *	En esta interfaz se definen las funciones que deben tener en comun todos los individuos
 */
public interface IIndividuo {
	/**
	 * Devuelve el nodo raiz del individuo
	 * @return El nodo raiz del individuo
	 */
    public INodo getExpresion();
    /**
     * Permite establecer el nodo raiz del individuo
     * @param expresion Nodo raiz establecido
     */
    public void setExpresion(INodo expresion);
    /**
     * Este valor devuelve la calidad del individuo para la resolucion del problema
     * @return El fitness del individuo
     */
    public double getFitness();
    /**
     * Permite establecer el fitness de un individuo
     * @param fitness Fitness que queremos dar al individuo
     */
    public void setFitness(double fitness);
    /**
     * Esta funcion permite crear un individuo aleatorio con ciertas cualidades
     * @param profundidad Profundidad del individuo
     * @param terminales Lista de terminales del individuo
     * @param funciones Lista de funciones del individuo
     * @throws ProfundidadInvalidaException La profundidad dada no coincide con las listas de terminales y funciones
     * @throws MaximosDescendientesException Se ha superado el maximo numero de descendientes de un nodo
     */
    public void crearIndividuoAleatorio(int profundidad, List<Terminal> terminales, List<Funcion> funciones) throws ProfundidadInvalidaException, MaximosDescendientesException;
    /**
     * Esta funcion realiza las operaciones pertinentes para obtener el resultado de la union de los 
     * terminales y funciones definidos en nuestro individuo en forma de nodos de arbol.
     * @return La expresion resultante
     */
    public double calcularExpresion();
    /**
     * Devuelve el numero de nodos que posee el individuo
     * @return Numero de nodos del individuo
     */
    public int getNumeroNodos();
    /**
     * Esta funcion imprime la expresion resultante del individuo
     */
    public void writeIndividuo();
    /**
     * Esta funcion permite inicializar todos los ID de los nodos del individuo de forma ordenada.
     */
    public void etiquetaNodos();
} 