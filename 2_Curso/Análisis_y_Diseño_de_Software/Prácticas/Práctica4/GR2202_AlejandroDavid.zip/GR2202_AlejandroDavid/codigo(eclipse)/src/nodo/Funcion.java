package nodo;

import java.util.*;

import excepciones.*;

/**
 * 
 * @author David Cabornero y Alejandro Santorum
 *
 *Esta clase abstracta permite definir todos los metodos y atributos que van a ser usados en cualquier funcion creada.
 *Recordemos que una funcion es un nodo que puede tener mas nodos hijos (funciones o terminales), con los que opera
 *en consecuencia.
 */
public abstract class Funcion extends Nodo{
    /**
     * Constructor de la clase Funcion
     * @param simbolo Simbolo asociado a la funcion
     * @param maxDescendientes Numero maximo de descendientes que se le permite tener a la funcion
     */
    public Funcion(String simbolo, int maxDescendientes){
        super(simbolo, maxDescendientes);
    }
    
    /**
     * Permite calcular el valor asociado a la funcion
     * @return Valor asociado
     */
    public abstract double calcular();
    
    /**
     * Permite copiar la funcion, al igual que todos sus hijos
     * @return Copia de la funcion
     */
    public abstract INodo copy() throws MaximosDescendientesException;
    
    /**
     * Crea una String que devuelve la expresion de la funcion relacionada con sus hijos
     */
    public String toString(){
        String aux;
        ArrayList<INodo> descendientes = this.getDescendientes();
        
        aux = "( "+this.getRaiz();
        
        for(INodo n: descendientes){
            aux += " "+n.toString()+" ";
        }
        
        aux += " )";
        
        return aux;
    }
    
}