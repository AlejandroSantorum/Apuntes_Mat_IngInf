package nodo;

/**
 * 
 * @author David Cabornero y Alejandro Santorum
 *En esta clase se pretende crear una terminal que tenga como valor un booleano.
 */
public class TerminalBooleano1 extends Terminal{
    private static int valor;
    /**
     * Constructor de la clase TerminalBooleano1
     * @param simbolo Simbolo que queremos dar al terminal (1 o 0)
     */
    public TerminalBooleano1(String simbolo){
        super(simbolo);
    }
    
    /**
     * Devulve el valor del terminal, 1 o 0
     * @return Valor del terminal
     */
    public double calcular(){
        return valor;
    }
    
    /**
     * Permite dar un cierto valor booleano
     * @param val Valor booleano que queremos dar
     */
    public static void setValor(int val){
        valor = val;
    }
    
    /**
     * Permite copiar el nodo, en esta ocasion sin hijos, dado que es un terminal
     * @return Nodo copiado
     */
    public INodo copy(){
        TerminalBooleano1 tb = new TerminalBooleano1(this.getRaiz());
        return tb;
    }
}