package nodo;

/**
 * 
 * @author David Cabornero y Alejandro Santorum
 * Esta clase nos permite trabajar con una terminal que contiene un valor aritmetico,
 * es decir, un numero decimal.
 *
 */
public class TerminalAritmetico extends Terminal{
    private static double valor;
    /**
     * Constructor de la clase TerminalAritmetico
     * @param simbolo Numero que queremos representar
     */
    public TerminalAritmetico(String simbolo){
        super(simbolo);
    }
    /**
     * Esta funcion devuelve, en este caso, el valor del terminal, es decir,
     * el numero asociado a el
     * @return Numero asociado al terminal
     */
    public double calcular(){
        return valor;
    }
    /**
     * Permite dar el valor que queremos que tenga nuestro terminal
     * @param val Valor deseado
     */
    public static void setValor(double val){
        valor = val;
    }
    /**
     * Permite copiar el terminal
     * @return Copia del Terminal
     */
    public INodo copy(){
        TerminalAritmetico ta = new TerminalAritmetico(this.getRaiz());
        return ta;
    }
}