package excepciones;

/**
 * 
 * @author David Cabornero y Alejandro Santorum
 * Esta excepcion sera lanzada cuando no se haya inicializado un parametro recibido,
 * y sin embargo deberia haber sido inicializado.
 *
 */
public class ParametroNoInicializadoException extends Exception{
	
	/**
	 * Constructor of the exception ParametroNoInicializadoException
	 * @param m Mensaje enviado a la consola para ser imprimido
	 */
	public ParametroNoInicializadoException(String m) {
		super(m);
	}

}