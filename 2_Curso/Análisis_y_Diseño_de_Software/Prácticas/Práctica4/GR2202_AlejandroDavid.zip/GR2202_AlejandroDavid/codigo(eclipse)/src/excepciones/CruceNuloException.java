package excepciones;

/**
*
* @author David Cabornero y Alejandro Santorum
* Esta excepcion sera lanzada cuando los nodos aleatorios por donde cruzar
* dos individuos sea en ambos la raiz, ya que el cruce seria nulo.
*
*/
public class CruceNuloException extends Exception{
	/**
	 * Constructor de la excepcion CruceNuloException
	 * @param m Mensaje enviado a la consola
	 */
	public CruceNuloException(String m) {
		super(m);
	}

}
