package nodo;

import java.util.*;

import excepciones.*;

/**
 * 
 * @author David Cabornero y Alejandro Santorum
 * 
 *	Esta interfaz define las funciones que debe incluir cualquier nodo.
 */
public interface INodo {
	/**
	 * Esta funcion nos devuelve la raiz del nodo
	 * @return Raiz del nodo
	 */
    public String getRaiz();
    /**
     * Esta funcion devuelve los nodos descendientes de nuestro nodo.
     * @return Lista de nodos descendientes
     */
    public List<INodo> getDescendientes();
    /**
     * Esta funcion anyade un descendiente nuevo a nuestro nodo
     * @param nodo Nodo que va a ser anyadido
     * @throws MaximosDescendientesException Superado el numero maximo de nodos permitidos
     */
    public void incluirDescendiente(INodo nodo)  throws MaximosDescendientesException;
    /**
     * Devuelve el valor asociado al nodo, en terminales sera el mismo valor del nodo, pero en 
     * funciones se deberan realizar las operaciones pertinentes.
     * @return Valor asociado al nodo
     */
    public double calcular();
    /**
     * Crea una copia del nodo, incluyendo una copia de sus descendientes
     * @return Copia del nodo
     * @throws MaximosDescendientesException Nunca se va a dar,
     * pero la funcion utiliza incluirDescendiente
     */
    public INodo copy() throws MaximosDescendientesException;
} 