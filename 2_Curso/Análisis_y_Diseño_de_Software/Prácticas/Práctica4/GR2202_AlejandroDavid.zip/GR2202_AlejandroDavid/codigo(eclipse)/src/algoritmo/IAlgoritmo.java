package algoritmo;



import java.util.*;

import excepciones.*;
import nodo.*;
import individuo_dominio.*;


/**
 * 
 * @author David Cabornero y Alejandro Santorum
 * 
 * Esta interfaz definira los metodos que debe tener cualquier algoritmo disenyado en esta
 * aplicacion.
 *
 */
public interface IAlgoritmo {
	/**
	 * Este metodo sirve para obtener la lista de terminales que usara el algoritmo
	 * @param terminales Lista de terminales pasada
	 */
    public void defineConjuntoTerminales(List<Terminal> terminales);
    /**
     * Este metodo sirve para obtener la lista de funciones que se van a usar
     * @param funciones Lista de funciones pasada
     * @throws ArgsDistintosFuncionesException Numero de maxDescendientes y simbolos distinto
     */
    public void defineConjuntoFunciones(List<Funcion> funciones) throws ArgsDistintosFuncionesException;
    /**
     * Este metodo nos genera una poblacion aleatoria
     * @throws ParametroNoInicializadoException Se ha recibido un parametro no inicializado
     * @throws CruceNuloException Se estan intentando intercambiar los dos nodos raiz
     * @throws ProfundidadInvalidaException La profundidad pasada no es coherente con el numero de
     * funciones y terminales
     * @throws MaximosDescendientesException Se ha superado el numero maximo permitido, definido por el 
     * atributo maxDescendientes
     */
    public void crearPoblacion() throws ParametroNoInicializadoException, CruceNuloException, ProfundidadInvalidaException, MaximosDescendientesException;
    /**
     * Implementamos el cruece entre dos individuos
     * @param prog1 Primer individuo
     * @param prog2 Segundo individuo
     * @return Individuo resultante del cruce
     * @throws CruceNuloException Se estan intentando intercambiar los dos nodos raiz
     * @throws MaximosDescendientesException Se ha superado el numero maximo permitido, definido por el 
     * atributo maxDescendientes
     */
    public List<IIndividuo> cruce(IIndividuo prog1, IIndividuo prog2) throws CruceNuloException, MaximosDescendientesException;
    /**
     * Se crea una nueva poblacion a partir de la poblacion anterior, mediante cruces.
     * @throws ParametroNoInicializadoException No se ha inicializado un parametro que deberia
     * haberse inicializado 
     * @throws CruceNuloException Se estan intentando intercambiar los dos nodos raiz
     * @throws ProfundidadInvalidaException La profundidad no es coherente con en numero de
     *  funciones y terminales dado
     * @throws MaximosDescendientesException Se ha superado el numero maximo permitido, definido por el 
     * atributo maxDescendientes
     */
    public void crearNuevaPoblacion() throws ParametroNoInicializadoException, CruceNuloException, ProfundidadInvalidaException, MaximosDescendientesException;
    /**
     * Funcion que se encarga de crear nuevas poblaciones hasta que se llegue al tope o hasta que
     * se encuentre la solucion al problema
     * @param dominio Dominio utilizado para plantear y encontrar la solucion
          * @throws ParametroNoInicializadoException No se ha inicializado un parametro que deberia
     * haberse inicializado 
     * @throws CruceNuloException Se estan intentando intercambiar los dos nodos raiz
     * @throws ProfundidadInvalidaException La profundidad no es coherente con en numero de
     *  funciones y terminales dado
     * @throws MaximosDescendientesException Se ha superado el numero maximo permitido, definido por el 
     * atributo maxDescendientes
     */
    public void ejecutar(IDominio dominio) throws ParametroNoInicializadoException, CruceNuloException, ProfundidadInvalidaException, MaximosDescendientesException;
}