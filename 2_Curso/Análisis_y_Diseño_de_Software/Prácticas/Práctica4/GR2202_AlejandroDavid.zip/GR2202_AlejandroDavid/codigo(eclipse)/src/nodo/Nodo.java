package nodo;

import java.util.*;

import excepciones.*;

/**
 * 
 * @author David Cabornero y Alejandro Santorum
 * Esta clase abstracta sirve para declarar todos los aspectos comunes de cualquier nodo de nuestra aplicacion.
 * En esta clase definimos tanto los atributos como las funciones comunes de los nodos. Si alguna funcion es identica
 * en cualquier nodo, tambien sera definida aqui.
 */
public abstract class Nodo implements INodo, Cloneable{
    int id;
    private String simbolo;
    private INodo padre;
    private int maxDescendientes;
    private ArrayList<INodo> descendientes;
    
    /**
     * Constructor de la clase Nodo
     * @param simbolo Simbolo asociado al nodo
     * @param maxDescendientes Maximo de descendientes que admite el nodo
     */
    public Nodo(String simbolo, int maxDescendientes){
        if(maxDescendientes < 0){
		      throw new IllegalArgumentException("maxDescendientes es menor que cero: " + maxDescendientes); 
		}
        descendientes = new ArrayList<INodo>();
        this.simbolo = simbolo;
        this.maxDescendientes = maxDescendientes;
        this.id = -1;
    }
    
    /**
     * Esta funcione nos devuelve el ID del nodo.
     * @return ID del nodo
     */
    public int getId(){
        return id;
    }
    
    /**
     * Esta funcion nos permite fijar el nuevo ID del nodo
     * @param id nuevo ID del nodo
     */
    public void setId(int id){
        this.id = id;
    }
    
    /**
	 * Esta funcion nos devuelve la raiz del nodo, es decir, el simbolo con el que se representa
	 * @return Raiz del nodo
	 */
    public String getRaiz(){
        return simbolo;
    }
    
    /**
     * Esta funcion nos permite averiguar el nodo padre
     * @return Nodo padre
     */
    public INodo getPadre(){
        return padre;
    }
    
    /**
     * Esta funcion nos permite fijar un nuevo nodo padre
     * @param padre Nodo padre que vamos a fijar
     */
    public void setPadre(INodo padre){
        this.padre = padre;
    }
    
    /**
     * Esta funcion devuelve los nodos descendientes de nuestro nodo.
     * @return Lista de nodos descendientes
     */
    public ArrayList<INodo> getDescendientes(){
        return descendientes;
    }
    
    /**
     * Esta funcion devuelve el numero de descendientes del nodo
     * @return Numero de descendientes
     */
    public int getNumDescendientes(){
        return descendientes.size();
    }
    
    /**
     * Esta funcion devuelve el numero maximo admisible de nodos
     * @return Maximo de nodos admitidos
     */
    public int getMaxDescendientes(){
        return maxDescendientes;
    }
    
    /**
     * Esta funcion anyade un descendiente nuevo a nuestro nodo
     * @param nodo Nodo que va a ser anyadido
     * @throws MaximosDescendientesException Superado el numero maximo de nodos permitidos
     */
    public void incluirDescendiente(INodo nodo) throws MaximosDescendientesException{
        if(this.descendientes.size() == maxDescendientes){
            throw new MaximosDescendientesException("Alcanzado el numero maximo de descendientes, no se puede incluir otro descendiente");
        }
        
        INodo copia = nodo.copy();
        this.descendientes.add(copia);
        ((Nodo) copia).padre = this;
    }
    
    /**
     * Devuelve el valor asociado al nodo, en terminales sera el mismo valor del nodo, pero en 
     * funciones se deberan realizar las operaciones pertinentes.
     * @return Valor asociado al nodo
     */
    public abstract double calcular();
    
    /**
     * Crea una copia del nodo, incluyendo una copia de sus descendientes
     * @return Copia del nodo
     * @throws MaximosDescendientesException Nunca se va a dar,
     * pero la funcion utiliza incluirDescendiente
     */
    public abstract INodo copy() throws MaximosDescendientesException;
    
    /**
     * Esta funcion devuelve todos los descendientes del nodo MAS EL PROPIO NODO
     * @return Array de los nodos descendientes
     */
    public ArrayList<INodo> getAllDescendientes(){
        ArrayList<INodo> arrayAuxiliar = new ArrayList<INodo>();
        ArrayList<INodo> ret = new ArrayList<INodo>();
        
        arrayAuxiliar.add(this);
        while(!arrayAuxiliar.isEmpty()){
            arrayAuxiliar.addAll(arrayAuxiliar.get(0).getDescendientes());
            ret.add(arrayAuxiliar.get(0));
            arrayAuxiliar.remove(0);
        }
        
        return ret;
    }
    
    /**
     * Esta funcion inicializa los IDs de los descendientes y del propio nodo con valores que van desde
     * 1 hasta el numero de descendientes.
     */
    public void etiquetarDescendientes(){
        ArrayList<INodo> array = this.getAllDescendientes();
        
        for(int i=0; i< array.size(); i++){
            ((Nodo) array.get(i)).setId(i+1);
        }
    }
    
    /**
     * Esta funcion devuelve el nodo descendiente que tiene cierto ID (devuelve null si no existe)
     * @param id ID del nodo a buscar
     * @return Nodo buscado
     */
    public INodo getDescendienteById(int id){
        ArrayList<INodo> arrayDes = this.getAllDescendientes();
        
        for(INodo n: arrayDes){
            if(((Nodo) n).getId() == id){
                return n;
            }
        }
        return null;
    }
    
    /**
     * Muestra en String los ID de los nodos descendientes, incluido el propio nodo
     * @return String con los ID mencionados
     */
    public String mostrarDescendientesIds(){
        String aux = "";
        
        if(this.descendientes.size() == 0){
            return " "+id+" ";
        }
        else{
            for(INodo n: descendientes){
                aux += ((Nodo) n).mostrarDescendientesIds();
            }
        }
        
        return aux+" "+id+" ";
    }
    
}
