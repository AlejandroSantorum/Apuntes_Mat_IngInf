package nodo;

import java.util.*;

import excepciones.*;
/**
 * 
 * @author David Cabornero y Alejandro Santorum
 * Esta funcion nos permite realizar una suma sobre todos sus nodos hijo
 *
 */
public class FuncionSuma extends Funcion{
    /**
     * Constructor de FuncionSuma
     * @param simbolo Simbolo asociado a la suma
     * @param maxDescendientes Numero maximo permitido de descendientes
     */
    public FuncionSuma(String simbolo, int maxDescendientes){
        super(simbolo, maxDescendientes);
    }
    /**
     * Calcula la suma de todos sus nodos hijo
     */
    public double calcular(){
        ArrayList<INodo> descendientes = this.getDescendientes();
        double calculo = 0;
        
        for(INodo n: descendientes){
            calculo += n.calcular();
        }
        return calculo;
    }
    
    /**
     * Permite copiar la funcion, al igual que todos sus hijos
     */
    public INodo copy() throws MaximosDescendientesException{
        FuncionSuma fs = new FuncionSuma(this.getRaiz(), this.getMaxDescendientes());
        
        ArrayList<INodo> arrayDes = this.getDescendientes();
        
        if(arrayDes.size() > 0){
            for(INodo n: arrayDes){
                INodo nuevo = n.copy();
                fs.incluirDescendiente(nuevo);
            }
        }
        
        return fs;
    }
}