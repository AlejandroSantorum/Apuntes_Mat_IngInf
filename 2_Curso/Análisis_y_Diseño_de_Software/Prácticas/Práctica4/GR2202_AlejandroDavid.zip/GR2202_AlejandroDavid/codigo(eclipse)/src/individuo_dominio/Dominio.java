package individuo_dominio;

import java.io.*;
import java.util.*;

import nodo.*;
import excepciones.*;
/**
 * 
 * @author David Cabornero y Alejandro Santorum
 * 
 * En esta clase implementaremos todas los metodos y los atributos que deben tener
 * en comun todos los dominios creados.
 *
 */
public abstract class Dominio implements IDominio{
    private double fitnessMaximo=-1.0;
    
    public abstract List<Terminal> definirConjuntoTerminales(String... terminales);
    public abstract List<Funcion> definirConjuntoFunciones(int[] argumentos, String... funciones) throws ArgsDistintosFuncionesException; 
    public abstract void definirValoresPrueba(String ficheroDatos) throws FileNotFoundException, IOException;    
    public abstract double calcularFitness(IIndividuo individuo, int flag); 
    /**
     * Getter que nos devuelve la lista de terminales definidos en el dominio
     * @return El array de terminales
     */
    public abstract List<Terminal> getTerminalesDefinidos();
    /**
     * Getter que nos devuelve la lista de funciones definidas en el dominio
     * @return El array de funciones
     */
    public abstract List<Funcion> getFuncionesDefinidas();
    /**
     * Getter que nos devuelve el fitness maximo calculado
     * @return Fitness maximo
     */
    public double getFitnessMaximo(){
        return fitnessMaximo;
    }
    /**
     * Setter que nos permite establecer un nuevo fitness maximo
     * @param fitness Nuevo fitness maximo
     */
    public void setFitnessMaximo(double fitness){
        this.fitnessMaximo = fitness;
    }
}