package individuo_dominio;

import java.io.*;
import java.util.*;

import nodo.*;
import excepciones.*;
/**
 * 
 * @author David Cabornero y Alejandro Santorum
 * 
 * En esta funcion, crearemos un dominio especificamente creado para tratar con las funciones
 * aritmeticas creadas: suma, resta y multiplicacion. Lo mismo podemos decir de sus terminales,
 * ya que deben ser numeros decimales.
 */
public class DominioAritmetico extends Dominio{
    private ArrayList<Double> valores;
    private ArrayList<Double> reales;
    private ArrayList<Double> estimados; /* OPCIONAL */
    private ArrayList<Terminal> terminalesDefinidos;
    private ArrayList<Funcion> funcionesDefinidas;
    
    /**
     * Constructor de DominoAritmetico, en el que solo debemos crear
     * listas vacias, por lo que no hay que pasar argumentos
     */
    public DominioAritmetico(){
        valores = new ArrayList<Double>();
        reales = new ArrayList<Double>();
        estimados = new ArrayList<Double>();
    }
    
    
    public List<Terminal> definirConjuntoTerminales(String... terminales){
        TerminalAritmetico aux;
        
        if(terminalesDefinidos==null){
            terminalesDefinidos = new ArrayList<Terminal>();
        }
        else{
            terminalesDefinidos.clear();
        }
        
        for(String simbolo: terminales){
            aux = new TerminalAritmetico(simbolo);
            terminalesDefinidos.add(aux);
        }
        
        return terminalesDefinidos;
    }
    
    
    public List<Funcion> definirConjuntoFunciones(int[] argumentos, String... funciones) throws ArgsDistintosFuncionesException{
        if(argumentos.length != funciones.length){
            throw new ArgsDistintosFuncionesException("El numero de simbolos de funciones es diferente al tamaño del array de argumentos");
        }
        
        if(funcionesDefinidas==null){
            funcionesDefinidas = new ArrayList<Funcion>();
        }
        else{
            funcionesDefinidas.clear();
        }
        
        for(int i=0; i<funciones.length; i++){
            String comparar = funciones[i];
            Funcion f;
            
            switch(comparar){
                case "+":
                    f = new FuncionSuma(comparar, argumentos[i]);
                    funcionesDefinidas.add(f);
                    break;
                    
                case "-":
                    f = new FuncionResta(comparar, argumentos[i]);
                    funcionesDefinidas.add(f);
                    break;
                    
                case "*":
                    f = new FuncionMultiplicacion(comparar, argumentos[i]);
                    funcionesDefinidas.add(f);
                    break;
                    
                default:
                    throw new ArgsDistintosFuncionesException("La cadena de caracteres simbolica no tiene ninguna correspondencia con las funciones definidas");
            }
        }
        
        return funcionesDefinidas;
    }
    
    /**
     * Definimos los valores de prueba para nuestra aplicacion, definidos en el fichero, guardandolos asi en atributos de nuestra clase.
     * En concreto, las lineas del fichero contendran dos valores: el primero refleja el valor sobre
     * el que evaluamos al individuo y el otro el resultado de esa evaluacion.
     */
    public void definirValoresPrueba(String ficheroDatos) throws FileNotFoundException, IOException{
        try(BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(ficheroDatos)))){
			String line;
			String[] items = new String[]{};
			double fitnessMaximo = 0.0;
			
			while((line = reader.readLine()) != null) {
				items = line.split(" ");
				
				if (items.length != 2) {
					throw new IOException("La línea leída no contiene exactamente dos datos.\n");
				}
				
				valores.add(Double.parseDouble(items[0]));
				reales.add(Double.parseDouble(items[1]));
				fitnessMaximo += 1.0;
			}
			super.setFitnessMaximo(fitnessMaximo);
		}catch(IOException ex) {
			throw ex;
		};
    }
    
    /**
     * @param flag Si es distinta de 0, imprimira los valores sobre los que se esta evaluando,
     * su resultado estimado y su resultado real.
     */
    public double calcularFitness(IIndividuo individuo, int flag){
        Double estimado, real;
        int fitness=0;
        
        for(int i=0; i<valores.size(); i++){
            TerminalAritmetico.setValor(valores.get(i));
            
            estimado = (individuo.getExpresion()).calcular();
            real = reales.get(i);
            
            if(flag!=0){
                System.out.println("Valor "+valores.get(i)+" <-> Rdo estimado: "+estimado+" <-> Rdo real: "+real);
            }
            
            estimados.add(estimado); /* OPCIONAL */
            
            if(Math.abs(real - estimado) <= 1){
                fitness += 1;
            }
        }
        individuo.setFitness(fitness);
        return fitness;
    }
    
    
    public ArrayList<Funcion> getFuncionesDefinidas(){
        return funcionesDefinidas;
    }
    
    public ArrayList<Terminal> getTerminalesDefinidos(){
        return terminalesDefinidos;
    }
}