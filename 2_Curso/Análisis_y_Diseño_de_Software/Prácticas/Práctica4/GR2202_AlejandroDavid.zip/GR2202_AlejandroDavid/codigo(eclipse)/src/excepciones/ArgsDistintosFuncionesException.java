package excepciones;

/**
 * 
 * @author David Cabornero y Alejandro Santorum
 *
 *Esta excepcion es lanzada cuando, al definir el array de funciones de un dominio,
 *se recibe un numero distinto de maxArgumentos y de simbolos. En conclusion, no se pueden
 *crear dichas funciones.
 */

public class ArgsDistintosFuncionesException extends Exception{
	
	/**
	 * Constructor de la exception ArgsDistintosFuncionesException
	 * @param m Mensaje mandado a la consola
	 */
	public ArgsDistintosFuncionesException(String m) {
		super(m);
	}

}