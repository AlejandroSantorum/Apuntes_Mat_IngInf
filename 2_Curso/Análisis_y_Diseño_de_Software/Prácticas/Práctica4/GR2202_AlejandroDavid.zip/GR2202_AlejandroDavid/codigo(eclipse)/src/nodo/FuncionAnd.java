package nodo;

import java.util.*;

import excepciones.*;
/**
 * 
 * @author David Cabornero y Alejandro Santorum
 *Esta clase permite operar nodos haciendo su producto logico
 */
public class FuncionAnd extends Funcion{
    /**
     * Constructor de la clase FuncionAnd
     * @param simbolo Simbolo asociado al producto logico
     * @param maxDescendientes Maximo de factores permitidos
     */
    public FuncionAnd(String simbolo, int maxDescendientes){
        super(simbolo, maxDescendientes);
    }
    /**
     * Permite calcular el valor del producto logico resultante
     */
    public double calcular(){
        ArrayList<INodo> descendientes = this.getDescendientes();
        double calculo = 1.0;
        
        for(INodo n: descendientes){
            calculo = FuncionAnd.and(calculo, n.calcular());
        }
        return calculo;
    }
    /**
     * Permite copiar la funcion, al igual que todos sus hijos
     */
    public INodo copy() throws MaximosDescendientesException{
        FuncionAnd fa = new FuncionAnd(this.getRaiz(), this.getMaxDescendientes());
        
        ArrayList<INodo> arrayDes = this.getDescendientes();
        
        if(arrayDes.size() > 0){
            for(INodo n: arrayDes){
                INodo nuevo = n.copy();
                fa.incluirDescendiente(nuevo);
            }
        }
        
        return fa;
    }
    
    /**
     * Funcion privada que permite operar dos operandos
     * @param op1 Primer operando
     * @param op2 Segundo operando
     * @return Resultado de la operacion
     */
    private static double and(double op1, double op2){
        if(op1==1.0 && op2==1.0) return 1.0;
        else return 0.0;
    }
    
}