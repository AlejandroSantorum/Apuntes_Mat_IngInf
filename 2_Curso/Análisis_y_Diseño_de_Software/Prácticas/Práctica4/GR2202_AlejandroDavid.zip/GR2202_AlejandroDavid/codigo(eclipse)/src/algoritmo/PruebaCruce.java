package algoritmo;


import java.util.*;

import excepciones.*;
import nodo.*;
import individuo_dominio.*;

/**
 * 
 * @author David Cabornero y Alejandro Santorum
 *Esta clase solo se utiliza para el main, contiene unicamente el metodo cruce y se usa para 
 *testear.
 */
public class PruebaCruce{
    /**
     * Generador de numeros enteros aleatorios
     * @param min Minimo numero aleatorio
     * @param max Maximo numero aleatorio
     * @return Numero aleatorio resultante
     */
    public static int aleat_num(int min, int max){
        Random rand = new Random();
        return (min + rand.nextInt((max-min)+1));
    }
    
    /**
     * Cruce entre dos individuos
     * @param ind1 Primer individuo
     * @param ind2 Segundo individuo
     * @return Lista de individuos resultantes del cruce
     * @throws CruceNuloException Se estan intentando intercambiar los dos nodos raiz
     * @throws MaximosDescendientesException Se ha superado el numero de descendientes especificado
     * por maxDescendientes
     */
    public ArrayList<IIndividuo> cruce(IIndividuo ind1, IIndividuo ind2) throws CruceNuloException, MaximosDescendientesException{
        INodo copia1 = ind1.getExpresion().copy();
        INodo copia2 = ind2.getExpresion().copy();
        
        int nNodos1 = ind1.getNumeroNodos();
        int nNodos2 = ind2.getNumeroNodos();
        
        ((Nodo) copia1).etiquetarDescendientes();
        ((Nodo) copia2).etiquetarDescendientes();
        
        int rand1 = aleat_num(1, nNodos1);
        int rand2 = aleat_num(1, nNodos2);
        if(rand1==1 && rand2==1){
            throw new CruceNuloException("Ambos numeros aleatorios son igual a uno");
        }
        System.out.println("");
        System.out.println("Punto de cruce del progenitor 1: "+rand1);
        System.out.println("Punto de cruce del progenitor 2: "+rand2);
        
        INodo nodoCruce1 = ((Nodo) copia1).getDescendienteById(rand1);
        INodo nodoCruce2 = ((Nodo) copia2).getDescendienteById(rand2);
        
        INodo padre1 = ((Nodo) nodoCruce1).getPadre();
        INodo padre2 = ((Nodo) nodoCruce2).getPadre();
        
        /* PRIMERA IMPLEMENTACION: NO IMPORTABA EL LUGAR DEL NODO DE CRUCE ESCOGIDO */
        
        /*
        if(padre1!=null) ((Nodo) padre1).getDescendientes().remove(nodoCruce1);
        if(padre2!=null) ((Nodo) padre2).getDescendientes().remove(nodoCruce2);
        
        if(padre1!=null){
            ((Nodo) padre1).getDescendientes().add(nodoCruce2);
            ((Nodo) nodoCruce2).setPadre(padre1);
        } 
        if(padre2!=null){
            ((Nodo) padre2).getDescendientes().add(nodoCruce1);
            ((Nodo) nodoCruce1).setPadre(padre2);
        } */
        
        /* ======================================================================== */
        
        
        /* SEGUNDA IMPLEMENTACION SI IMPORTA EL LUGAR DEL NODO DE CRUCE ESCOGIDO */
        if(padre1!=null){
            ((Nodo)padre1).getDescendientes().set(((Nodo)padre1).getDescendientes().indexOf(nodoCruce1), nodoCruce2);
        }
        if(padre2!=null){
            ((Nodo)padre2).getDescendientes().set(((Nodo)padre2).getDescendientes().indexOf(nodoCruce2), nodoCruce1);
        }
        /* ======================================================================= */
        
        IIndividuo nuevo1 = new Individuo();
        nuevo1.setExpresion(copia1);
        IIndividuo nuevo2 = new Individuo();
        nuevo2.setExpresion(copia2);
        
        ArrayList<IIndividuo> arrayInd = new ArrayList<IIndividuo>();
        arrayInd.add(nuevo1);
        arrayInd.add(nuevo2);
        
        return arrayInd;
    }
    
}