package excepciones;

/**
 * 
 * @author David Cabornero y Alejandro Santorum
 *Esta excepcion sera lanzada cuando se supere el numero maximo de 
 *descendientes permitidos en un nodo.
 */
public class MaximosDescendientesException extends Exception{
	
	/**
	 * Constructor de la excepcion MaximosDescendientesException
	 * @param m Mensaje enviado a la consola
	 */
	public MaximosDescendientesException(String m) {
		super(m);
	}

}