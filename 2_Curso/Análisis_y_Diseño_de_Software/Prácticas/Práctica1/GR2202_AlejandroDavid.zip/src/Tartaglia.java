/**
 * Esta aplicación tiene la finalidad de imprimir una representación
 * semenjante al triángulo de Tartaglia, con un número de filas igual
 * al número n pasado como argumento de entrada.
 *
 * @author Alejandro Santorum Varela y David Cabornero Pascual - alejandro.santorum@estudiante.uam.es / david.cabornero@estudiante.uam.es
 *
 */

public class Tartaglia {
  /**
  * Atributos de la clase Tartaglia
  */
  private Combinatoria comb;
  private int num;

  /**
  * Constructor, se encarga de inicializar los atributos de la clase con los deseados por el usuario.
  * @param c Objeto de la clase Combinatoria, que nos permite acceder a sus métodos.
  * @param n Número de filas del triángulo de Tartaglia que se quieren imprimir.
  */
  public Tartaglia(Combinatoria c, int n){
    comb = c;
    num = n;
  }

  /**
  * Modificación del método toString. Debido a que System.out.printl llama a esta función internamente
  * para transformar su argumento en una string, vamos a aprovechar esto para modificar la función
  * y cuando println utilice esta función haga lo que nosotros nos interesa: imprimir
  * el triángulo de Tartaglia.
  * @return String con el triángulo de Tartaglia a imprimir.
  */
  public String toString(){
    String aux;
    int i, k;

    aux = "";
    for(i=0; i<num; i++){
      for(k=0; k<=i; k++){
        aux = aux + comb.combinaciones(i, k) + " ";
      }
      aux = aux + "\n";
    }
    return aux;
  }

  /**
   * Punto de entrada a la aplicación.
   *
   * <p>Este método imprime el triángulo de Tartaglia de n filas con ayuda de
   * otros métodos, ya explicados.</p>
   *
   * @param args espera como argumento de entrada el número de filas del triángulo a imprimir.
   */
  public static void main(String[] args){
      Combinatoria c = new Combinatoria();
      Tartaglia t = new Tartaglia(c, Integer.parseInt(args[0]));
      System.out.println(t);
  }
}
