
package p2.autoescuela.clases;


public class TesterAutoescuela {

	/**
	 * @param args Argumentos pasados para linea de comandos (tener en cuenta que este programa no necesita
	 * ningun argumento)
	 */
	public static void main(String[] args) {
		Alumno a1=new Alumno("3141243T","Jose", "Jimenez",2016,10,3,"A");
		Alumno a2=new Alumno("3141243T","Sandra", "Goya",2016,22,3,"C");
		Alumno a3=new Alumno("3141243T","Carlos","Pascual",2015,2,29,"E"); //Creamos 3 alumnos
		
		Fecha c1=a1.getFechaMatr();
		Fecha c2=a2.getFechaMatr();
		Fecha c3=a3.getFechaMatr(); //Creamos 3 fechas (2 no válidas)
		
		System.out.println("isValida <"+c1+"> ? "+c1.isFechaValida());
		System.out.println("isValida <"+c2+"> ? "+c2.isFechaValida());
		System.out.println("isValida <"+c3+"> ? "+c3.isFechaValida());
		System.out.println("Datos de alumno 1:\n"+ a1);
		System.out.println();
		
		
		Autoescuela au1=new Autoescuela("CODIGO", "DIRECCION", "UAM"); //Creamos una autoescuela
		
		Profesor p1=new Profesor("455632", "Monica", "Galindo", "88461", 900);
		au1.anadirProfesor(p1,c1);
		au1.finalizarContrato(p1,c3);
		
		Profesor p2=new Profesor("455631", "Benito", "Canela", "12121", 900);
		au1.anadirProfesor(p2,c2);
		
		au1.printContratos();
	}

}
