package p2.autoescuela.clases;

/**
 * Clase que permite crear una persona. La persona no esta pensada para existir por si misma, sino que se ha creado
 * para formar parte de la informacion de un alumno o un profesor. Es por eso que la clase es abstracta.
 * 
 * @author Alejandro Santorum Varela y David Cabornero Pascual - alejandro.santorum@estudiante.uam.es / david.cabornero@estudiante.uam.es
 *
 */
abstract public class Persona{
	private String dni;
	private String nombre;
	private String apellido;
	private String telefono;
	private Fecha fecha_nacimiento;
	
	/**
	 * Constructor de la clase Persona
	 * @param dni DNI de la persona
	 * @param nom Nombre de la persona
	 * @param ape Apellido de la persona
	 */
	public Persona(String dni, String nom, String ape){
		this.dni = dni;
		this.nombre = nom;
		this.apellido = ape;
	}
	
	/**
	 * Da el nombre de la persona
	 * @return Nombre de la persona
	 */
	public String getNombre(){
		return this.nombre;
	}
	 
	/**
	  * Da los apellidos de la persona
	  * @return Apellido de la persona
	  */
	public String getApellido(){
		return this.apellido;
	}
	
	/**
	 * Da el DNI de la persona
	 * @return DNI de la persona
	 */
	public String getDni(){
		return this.dni;
	}
	
	
}