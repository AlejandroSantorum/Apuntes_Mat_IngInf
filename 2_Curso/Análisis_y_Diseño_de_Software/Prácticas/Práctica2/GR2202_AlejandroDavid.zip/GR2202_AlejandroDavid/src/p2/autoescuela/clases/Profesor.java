 package p2.autoescuela.clases;

import p2.autoescuela.clases.Persona;

/**
 * Implementacion de la clase Profesor que es una especializacion de la clase Persona.
 * Permite gestionar los datos referentes a un tipo de objeto que simula un prefesor real.
 *
 * @author Alejandro Santorum Varela y David Cabornero Pascual - alejandro.santorum@estudiante.uam.es / david.cabornero@estudiante.uam.es
 *
 */
public class Profesor extends Persona{
/**
 * Atributos de la clase Persona
 */
	private String numero_ss;
	private float sueldo;
	
  /**
   * Contructor de Profesor, inicializa los atributos de un objeto Profesor con los deseados por el usuario.
   * @param dni DNI del profesor
   * @param nom nombre del profesor
   * @param ape apellidos del profesor
   * @param ss numero de la seguridad social
   * @param sueldo sueldo del profesor
   */
	public Profesor(String dni, String nom, String ape, String ss, float sueldo){
		super(dni,nom,ape);
		this.numero_ss = ss;
		this.sueldo = sueldo;
	}
	
  /**
	 * Convierte en una String el profesor, pasando el nombre y los apellidos.
	 */
	public String toString(){
		return this.getNombre() + " " + this.getApellido();
	}
	
  /**
  * Metodo que comprueba si dos objetos Profesor son iguales.
  * @param p Profesor que es comparado con el profesor objeto al que se le aplica el metodo.
  * @return Boolean, true si son iguales, false si son distintos.
  */
	public Boolean equals(Profesor p){
		if(numero_ss == p.numero_ss){
			return true;
		}
		return false;
	}
}
