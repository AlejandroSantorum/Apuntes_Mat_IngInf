package p2.autoescuela.clases;

/**
 * Clase auxiliar que nos deja crear una fecha corriente.
 * 
 * @author Alejandro Santorum Varela y David Cabornero Pascual - alejandro.santorum@estudiante.uam.es / david.cabornero@estudiante.uam.es
 *
 */
public class Fecha {
	
	private int anyo;
	private int mes;
	private int dia;
	
	/**
	 * Constructor de la clase Fecha
	 * @param anyo Año de la fecha
	 * @param mes Mes de la fecha
	 * @param dia Dia de la fecha
	 */
	public Fecha(int anyo, int mes, int dia){
		this.anyo = anyo;
		this.mes = mes;
		this.dia = dia;
	}
	
	/**
	 * Muestra las fechas en formato ingles, con año, mes y dia separados por tildes
	 */
	public String toString(){
		String str;
		str = anyo + "-" + mes + "-" + dia;
		
		return str;
	}
	
	/**
	 * Comprueba que la fecha es valida, teniendo en cuenta los dias bisiestos segun el calendario gregoriano
	 * @return Comprobacion de que la fecha es correcta
	 */
	public boolean isFechaValida(){
		if(anyo < 1950 || mes < 1 || mes >12 || dia <1|| dia>31){
			return false;
		}
		if(mes == 4 || mes == 6 || mes == 9 || mes == 11){
			if(dia == 31){
				return false;
			}
		}
		else if(mes == 2){
			if(dia>29){
				return false;
			}
			if(anyo%4 != 0 || (anyo%100 == 0 && anyo%400 != 0)){
				if(dia == 29){
					return false;
				}
			}
		}
		return true;
	}
	
		
}
