package p2.autoescuela.clases;

import java.util.*;
/**
 * En esta clase se pretende instanciar y modificar una autoescuela, base del programa; el resto de elementos de esta
 * clase pretender completarla. En ella se guardarán sus alumnos, los profesores y sus respectivos contratos.
 * 
 * @author Alejandro Santorum Varela y David Cabornero Pascual - alejandro.santorum@estudiante.uam.es / david.cabornero@estudiante.uam.es
 *
 */
public class Autoescuela {
	private ArrayList<Profesor> profesores = new ArrayList<Profesor>();
	private String codigo_interno;
	private String direccion;
	private String nombre;
	private ArrayList<Contrato> contratos = new ArrayList<Contrato>();
	private ArrayList<Alumno> alumnos = new ArrayList<Alumno>();
	
	/**
	 * Constructor de la clase Autoescuela
	 * @param codi El codigo interno de la autoescuela
	 * @param dir La direccion en la que se halla la autoescuela
	 * @param nom El nombre de la autoescuela
	 */
	public Autoescuela(String codi, String dir, String nom){
		this.codigo_interno = codi;
		this.direccion = dir;
		this.nombre = nom;
	}
	
	/**
	 * Pasa a formato String la autoescuela. En este caso hemos visto conveniente incluir unicamente el nombre
	 */
	public String toString(){
		return this.nombre;
	}
	
	/**
	 * Permite añadir un nuevo profesor a la autoescuela, una vez instanciado, creando a su vez su contrato.
	 * @param prof Profesor de la autoescuela a añadir ya instanciado
	 * @param ini Fecha de inicio de contato del profesor
	 */
	public void anadirProfesor(Profesor prof, Fecha ini){
		profesores.add(profesores.size(),prof);
		contratos.add(contratos.size(),new Contrato(prof, this, ini));
	}
	
	/**
	 * Permite añadir un nuevo alumno ya instanciado a la autoescuela. A diferencia del profesor, no debemos pedirle una
	 * fecha, pues la clase Alumno si contempla la fecha de matriculacion.
	 * @param a Nuevo alumno matriculado.
	 */
	public void anadirAlumno(Alumno a){
		alumnos.add(alumnos.size(),a);
	}
	
	/**
	 * Metodo privado que devuelve el contrato referido al profesor correspondiente. Esta funcion se utilizara para
	 * facilitar la funcion finalizarContrato.
	 * @param p Profesor del cual queremos hallar el contrato
	 * @return Contrato del susodicho profesor
	 */
	private Contrato getContrato(Profesor p){
		for(Contrato c: contratos){
			if(p.equals(c.getProfesor())==true){
				return c;
			}
		}
		return null;
	}
	
	/**
	 * Permite mostrar que el contrato entre la autoescuela y cierto profesor ha expirado, modificando la lista de 
	 * profesores contratados y modificando su contrato.
	 * @param p Profesor que ya no trabaja en la autoescuela
	 * @param fin Fecha en la que se marcha de la autoescuela
	 */
	public void finalizarContrato(Profesor p, Fecha fin){
		Contrato c = getContrato(p);
		c.expirar(fin);
		
		for(int i=0; i<profesores.size(); i++){
			if(profesores.get(i).equals(p)){
				profesores.remove(i);
			}
		}
	}
	
	/**
	 * Imprime por pantalla todos los contratos relativos a la autoescuela.
	 */
	public void printContratos(){
		for(Contrato c: contratos){
			System.out.println(c);
		}
	}
}
