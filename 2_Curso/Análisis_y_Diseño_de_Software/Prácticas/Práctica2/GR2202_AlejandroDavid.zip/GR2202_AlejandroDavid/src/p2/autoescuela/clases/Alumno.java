package p2.autoescuela.clases;

import p2.autoescuela.clases.Persona;
/**
 *Esta clase pretende crear y gestionar al informacion sobre los alumnos. Los alumnos que se creen 
 *estan pensados para formar parte del array de alumnos matriculados de la autoescuela, no estan 
 *pensados para existir independientemente. 
 *
 * @author Alejandro Santorum Varela y David Cabornero Pascual - alejandro.santorum@estudiante.uam.es / david.cabornero@estudiante.uam.es
 */
public class Alumno extends Persona{
	/**
	 * Atributos de la clase Alumno:
	 */
	private String carnets_tiene;
	private String carnet_matriculado;
	private float descuento;
	private Fecha fecha_matriculado;
	private Fecha fecha_teorico;
	private Fecha fecha_practico;
	
	/**
	 * Constructor de la clase alumno: se encarga de inicializar los atributos
	 * @param dni DNI del alumno
	 * @param nom Nombre del alumno
	 * @param ape Apellidos del alumno
	 * @param anyo Año de matriculacion del alumno
	 * @param mes Mes de matriculacion del alumno
	 * @param dia Dia de matriculacion del alumno
	 * @param matr Carnet para el que se ha matriculado el alumno
	 */
	public Alumno(String dni, String nom, String ape, int anyo, int mes, int dia, String matr){
		super(dni, nom, ape);
		this.fecha_matriculado = new Fecha(anyo, mes, dia);
		this.carnet_matriculado = matr;
	}
	
	/**
	 * Convierte en una String el alumno, dando su nombre, apellido, DNI, fecha de matriculacion y el tipo de carnet
	 * para el que se ha matriculado
	 */
	public String toString(){
		String str;
		str = "\t Nombre: " + this.getNombre() + "\n";
		str = str + "\t Apellido: " + this.getApellido() + "\n";
		str = str + "\t DNI: " + this.getDni() + "\n";
		str = str + "\t Fecha Matrícula: " + fecha_matriculado + "\n";
		str = str + "\t Tipo Carnet: " + carnet_matriculado + "\n";
		
		return str;
	}
	
	/**
	 * Devuelve la fecha de matriculacion del alumno
	 * @return Fecha de matriculacion
	 */
	public Fecha getFechaMatr(){
		return fecha_matriculado;
	}
}
