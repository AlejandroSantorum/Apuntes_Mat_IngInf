package p2.autoescuela.clases;

/**
 * En esta clase, se pretende crear un contrato, a la vez que se pretende que se pueda mostrar la expiracion de dicho
 * contrado con cierta autoescuela.
 * 
 * @author Alejandro Santorum Varela y David Cabornero Pascual - alejandro.santorum@estudiante.uam.es / david.cabornero@estudiante.uam.es
 *
 */
public class Contrato {
	private Profesor profesor;
	private Autoescuela autoescuela;
	private Fecha fecha_inicio;
	private Fecha fecha_final;
	private Boolean expirado = false;
	
	/**
	 * Constructor de la clase Contrato
	 * @param p Profesor con el que la autoescuela firma el contrato
	 * @param a Autoescuela que contrata al profesor
	 * @param ini Fecha en la que se firma el contrato
	 */
	public Contrato(Profesor p, Autoescuela a, Fecha ini){
		this.profesor = p;
		this.autoescuela = a;
		this.fecha_inicio = ini;
	}
	
	/**
	 * Permite obtener al profesor que ha firmado el contrato
	 * @return Profesor que firmo el contrato
	 */
	public Profesor getProfesor(){
		return this.profesor;
	}
	
	/**
	 * Permite mostrar el contrato como una string, indicando en una frase el nombre del profesor, la autoescuela,
	 * la fecha inicial del contrato y la fecha final en el caso de que haya expirado el contrato.
	 */
	public String toString(){
		String str = "El profesor " + profesor + " trabajo en la autoescuela "
	+ autoescuela + " desde el " + fecha_inicio;
		if(expirado == true){
			str += " hasta el " + fecha_final;
		}
		return str;
	}
	
	/**
	 * El metodo se utiliza para finalizar el contrato con el profesor
	 * @param fin Fecha en la que ha expirado el contrato
	 */
	public void expirar(Fecha fin){
		expirado = true;
		fecha_final = fin;
	}
	
	
}
