package grafos;

/**
 * Excepcion lanzada cuando se intenta crear un vertice con un ID que ya existe en otro vertice del grafo.
 * @author David Cabornero y Alejandro Santorum
 *
 */

public class VerticeIdException extends Exception{
	
	/**
	 * Constructor of the exception VerticeIdException
	 * @param m Message sent to the console if the exception is thrown
	 */
	public VerticeIdException(String m) {
		super(m);
	}

}