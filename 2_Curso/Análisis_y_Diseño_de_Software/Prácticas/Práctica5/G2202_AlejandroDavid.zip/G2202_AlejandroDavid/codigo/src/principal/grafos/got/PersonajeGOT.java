package grafos.got;


/**
 * Esta clase conforma los datos de los vertices en el grafoGOT. En este tipo de datos, guardaremos
 * el nombre de un personaje de GOT, junto con la casa a la que pertenece.
 * @author David Cabornero y Alejandro Santorum
 *
 */
public class PersonajeGOT implements Comparable{
    private String nombre;
    private String casa;
    /**
     * Constructor de PersonajeGOT
     * @param nombre Nombre del personaje de GOT
     * @param casa Casa del personaje de GOT(null si no pertenece a ninguna)
     */
    public PersonajeGOT(String nombre, String casa){
        this.nombre = nombre;
        this.casa = casa;
    }
    
    /**
     * Constructor de PersonajeGOT para cuando el personaje no pertenezca a ninguna casa
     * @param nombre Nombre del personaje de GOT
     */
    public PersonajeGOT(String nombre){
        this(nombre, null);
    }
    
    /**
     * Getter que devuelve el nombre del personaje
     * @return Nombre del personaje
     */
    public String getNombre(){
        return nombre;
    }
    
    /**
     * Getter que devuelve la casa del personaje
     * @return Casa del personaje
     */
    public String getCasa(){
        return casa;
    }
    
    /**
     * Este toString muestra toda la informacion del personaje: el nombre y la casa a la que pertenece.
     */
    public String toString() {
    	return "Nombre: " + nombre + "Casa: " + casa + "\n";
    }

	@Override
	public int compareTo(Object pers) {
		PersonajeGOT p = (PersonajeGOT) pers;
		if(p.getNombre().equals(nombre) && p.getCasa().equals(casa)) {
			return 0;
		}
		return -1;
	}
}