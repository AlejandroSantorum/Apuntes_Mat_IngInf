package grafos.got.simulador;

import java.io.IOException;

import java.util.*;
import java.util.stream.Collectors;
import grafos.*;
import grafos.got.*;
/**
 * Clase heredada de 'Subject', relativo al patron de diseno Observer. En el simulador, realizaremos interacciones
 * aleatorias entre los personajes que deben registrar los observadores.
 * @author David Cabornero y Alejandro Santorum
 *
 */
public class SimuladorGOT extends Subject {
	private GrafoGOT grafo;
	private PersonajeGOT origen;
	private List<PersonajeGOT> destinos = new ArrayList<>();
	private Map<String, Integer> gradoPonderado;
	
	/**
	 * Constructor de SimuladorGOT
	 * @param g Grafo de GOT sobre el que se hara la simulacion
	 * @throws VerticeIdException Se ha intentado crear un vertice con un ID que ya tenia otro vertice
	 */
	public SimuladorGOT(GrafoGOT g) throws VerticeIdException {
		this.grafo = g;
		List<Vertice<PersonajeGOT>> vertices = grafo.getVertices();
		gradoPonderado = grafo.gradoPonderadoPersonajes();
		for (Vertice<PersonajeGOT> v : vertices) {
			new ObservadorGOT(this, v.getDatos());
		}
	}
	
	/**
	 * Getter que nos permite saber cuales son los destinos de la ultima interaccion.
	 * @return Lista de personajes con los que el origen interactua
	 */
	public List<PersonajeGOT> getDestinos() {
		return this.destinos;
	}
	
	/**
	 * Getter que nos permite saber el origen de la ultima interaccion
	 * @return Personaje del que viene la ultima interaccion
	 */
	public PersonajeGOT getOrigen() {
		return this.origen;
	}
	
	/**
	 * Este metodo realiza una posible interaccion con cada personaje con el que esta relacionado, donde
	 * cada personaje tiene mas posibilidades de tener una interaccion si el arista que relaciona el origen
	 * con ese personaje tiene mucho peso.
	 * @param nombre Nombre del origen de las interacciones
	 * @throws PersonajeNoExisteException El personaje que se quiere obtener no existe
	 * @throws AristaInvalidaException Nos hemos intentado referir a un arista que no existe
	 */
	public void interaccion(String nombre) throws PersonajeNoExisteException, AristaInvalidaException {
		double aleat, porcion;
		int pesoTotal = gradoPonderado.get(nombre);
		List<Vertice<PersonajeGOT>> allDestinos;
		Vertice<PersonajeGOT> vertice = grafo.getVertice(nombre);
		origen = vertice.getDatos();
		destinos.clear();

		allDestinos = grafo.getVecinosDe(vertice);
		for (Vertice<PersonajeGOT> p : allDestinos) {
			aleat = Math.random();
			porcion = grafo.getPesoDe(vertice, p) / gradoPonderado.get(p.getDatos().getNombre());
			if (porcion > aleat) {
				destinos.add(p.getDatos());
			}
		}
		super.notificar();
	}
	
	/**
	 * Metodo toString, que constiste en definir las interacciones que ha tenido cada observador, llamando al toString
	 * de cada observador
	 */
	public String toString() {
		String text = "";
		Iterator<Observer> it;
		it = observers.iterator();
		while (it.hasNext()) {
			text += it.next();
		}
		return text;
	}
	
	/**
	 * Tester que va a permitir probar la funcionalidad de los observadores y este simulador.
	 * @param args Unico argumento, que debe ser un entero, que reflejara el numero de interacciones
	 * @throws AristaInvalidaException Se ha intentado acceder a una arista que no existe
	 * @throws VerticeIdException Se ha intentado crear un vertice con un ID ya usado
	 * @throws IOException Error en la apertura de ficheros
	 * @throws ArgsException Error al pasar el argumento
	 * @throws PersonajeNoExisteException Se ha intentado conseguir un personaje que no existe en el grafo
	 */
	public static void main(String[] args)
			throws AristaInvalidaException, VerticeIdException, IOException, ArgsException, PersonajeNoExisteException {
		int N, aleat;
		if (args.length != 1)
			throw new ArgsException("Se debe introducir como unico argumento el numero de iteraciones\n");
		try{
			N = Integer.parseInt(args[0]);
		}
		catch(NumberFormatException e) {
			throw new ArgsException("Se debe introducir como unico argumento el numero de iteraciones (un entero)\n");
		}
		if (N <= 0)
			throw new ArgsException("El numero de iteraciones debe ser positivo");

		String aleatNombre;
		GrafoGOT grafo = new GrafoGOT("vertices.csv", "arcos.csv");
		SimuladorGOT sim = new SimuladorGOT(grafo);
		List<Vertice<PersonajeGOT>> vertices = grafo.getVertices();
		List<String> nombres = vertices.stream().map(Vertice<PersonajeGOT>::getDatos).map(PersonajeGOT::getNombre)
				.collect(Collectors.toList());

		for (int i = 0; i < N; i++) {
			aleat = (int) (Math.random()*nombres.size());
			aleatNombre = nombres.get(aleat);
			sim.interaccion(aleatNombre);
		}
		
		System.out.println(sim);
	}
}
