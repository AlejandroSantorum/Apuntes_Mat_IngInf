package grafos.got.simulador;

/**
 *  En esta clase reside la excepcion que sera lanzada cuando los argumentos que se den al programa no concuerden con
 *	los solicitados
 * @author David Cabornero y Alejandro Santorum
 */
public class ArgsException extends Exception {
	/**
	 * Constructor of the exception ArgsException
	 * @param m Message sent to the console if the exception is thrown
	 */
	public ArgsException(String m) {
		super(m);
	}
}
