package grafos.got;

import java.io.*;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import grafos.*;

/**
 * Esta clase va a implementar un tipo concreto de grafo no dirigido: aquel en el que los vertices guardan
 * la informacion relativa a un personaje de Juego de Tronos. 
 * @author David Cabornero y Alejandro Santorum
 *
 */
public class GrafoGOT extends GrafoNoDirigido{
	/**
	 * Constructor de la clase GrafoGOT
	 * @param ficheroVertices Nombre del fichero que contiene la informacion necesaria para crear todos los vertices
	 * @param ficheroArcos Nombre del fichero que contiene la informacion necesaria para crear todos los arcos
	 * @throws IOException Error en la apertura de ficheros
	 * @throws VerticeIdException Se ha intentado crear un vertice con un ID ya usado por otro vertice
	 */
    public GrafoGOT(String ficheroVertices, String ficheroArcos) throws IOException, VerticeIdException{
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(ficheroVertices)));
		String line;
		String[] items = new String[] {};
		while ((line = reader.readLine()) != null) {
			items = line.split(",");
			if (items.length != 3) {
				throw new IOException("Una linea del fichero de vertices no tiene tres argumentos.\n");
			}
			this.addVertice(new PersonajeGOT(items[1], items[2]));
		}
            
        
		reader = new BufferedReader(new InputStreamReader(new FileInputStream(ficheroArcos)));
		while ((line = reader.readLine()) != null) {
			items = line.split(",");
			if (items.length != 3) {
				throw new IOException("Una linea del fichero de arcos no tiene tres argumentos.\n");
			}
			this.addArco((Vertice<PersonajeGOT>) this.vertices.get(Integer.parseInt(items[0])),
					(Vertice<PersonajeGOT>) this.vertices.get(Integer.parseInt(items[1])), Integer.parseInt(items[2]));
		}
    }
    
    /**
     * Metodo que nos permite obtener cierto vertice una vez conocido el nombre del personaje de GOT
     * @param nombre Nombre del personaje de GOt del que queremos obtener el vertice
     * @return Vertice que queremos obtener
     * @throws PersonajeNoExisteException El personaje solicitado no existe
     */
    public Vertice<PersonajeGOT> getVertice(String nombre) throws PersonajeNoExisteException{
    	List<Vertice<PersonajeGOT>> personajes = new ArrayList(this.vertices.values());
            
        List<Vertice<PersonajeGOT>> elegidos= personajes.stream().filter(p -> 
            p.getDatos().getNombre().equals(nombre)).collect(Collectors.toList());
        
        if(elegidos.size() == 0){
            throw new PersonajeNoExisteException("No hay ningun personaje llamado " + nombre);
        }
        
        return elegidos.get(0);
    }
    
    /**
     * Metodo que devuelve una lista ordenada de todas las casas de los personaje de GOT sin repetir y sin incluir null
     * @return Lista de las casas
     */
    public List<String> casas(){
        List<Vertice<PersonajeGOT>> personajes = new ArrayList(this.vertices.values());
        
        Set<String> elegidos = personajes.stream().map(Vertice<PersonajeGOT>::getDatos).map(
            PersonajeGOT::getCasa).filter(c -> (c.equals("null") == false)).collect(Collectors.toSet());
        List<String> aux = new ArrayList<>();
        aux.addAll(elegidos);
        aux.sort(null);
        return aux;
    }
    
    /**
     * Metodo que devuelve los nombres de los miembros de cierta casa
     * @param casa Casa de la que queremos recibir los nombres
     * @return Lista de los nombres de los personajes pertenecientes a la casa
     */
    public List<String> miembrosCasa(String casa){
        List<Vertice<PersonajeGOT>> personajes = new ArrayList(this.vertices.values());

    	Predicate<String> pertenece = x -> x.equals(casa);
    	
    	List<String> elegidos = (personajes.stream().map(Vertice<PersonajeGOT>::getDatos).filter(
    			c -> pertenece.test(c.getCasa()))).map(PersonajeGOT::getNombre).collect(Collectors.toList());
    	
    	return elegidos;
    }
    
    /**
     * Funcion que devuelve un mapa que relaciona cada personaje con el numero de personajes con los que se relaciona
     * @return Mapa en el que la clave es el nombre del personaje y su valor relacionado es el numero de aristas
     */
    public Map<String, Integer> gradoPersonajes(){
    	Map<String, Integer> mapa = new HashMap<String, Integer>();
        List<Vertice<PersonajeGOT>> personajes = new ArrayList(this.vertices.values());
    	
    	List<String> nombres = personajes.stream().map(Vertice<PersonajeGOT>::getDatos).map(
    			PersonajeGOT::getNombre).collect(Collectors.toList());
    	List<Integer> grados = personajes.stream().map(Vertice<PersonajeGOT>::getConexionesIn).map(
    			p -> p.size()).collect(Collectors.toList());
    	
    	for(int i=0; i<nombres.size(); i++) {
    		mapa.put(nombres.get(i), grados.get(i));
    	}
    	return mapa;
    }
    
    /**
     * Metodo que devuelve un mapa que relaciona cada personaje con la suma de pesos de sus aristas
     * @return Mapa cuyas claves son los nombres de los personajes y los valores asociados los pesos totales mencionados
     */
    public Map<String, Integer> gradoPonderadoPersonajes(){
    	Map<String, Integer> mapa = new HashMap<String, Integer>();
        List<Vertice<PersonajeGOT>> personajes = new ArrayList(this.vertices.values());
    	
    	List<String> nombres = personajes.stream().map(Vertice<PersonajeGOT>::getDatos).map(
    			PersonajeGOT::getNombre).collect(Collectors.toList());
    	List<Double> gradosSum = personajes.stream().map(Vertice<PersonajeGOT>::getConexionesIn).map(
    			p -> p.values().stream().reduce(0.0,(x,y)->x+y)).collect(Collectors.toList());
    	
    	for(int i=0; i<nombres.size(); i++) {
    		mapa.put(nombres.get(i), gradosSum.get(i).intValue());
    	}
    	return mapa;
    }
    
    /**
     * Metodo que devuelve un mapa que relaciona cada personaje con la suma de pesos de sus aristas, pero en esta
     * ocasion solo devuelve aquellos personajes que se encuentren por encima de la media de los pesos totales obtenidos
     * en gradoPonderadoPersonajes()
     * @return Mapa cuyas claves son los nombres de los personajes  seleccionados y los valores 
     * asociados los pesos totales mencionados
     */
    public Map<String, Integer> personajesRelevantes(){
    	Map<String,Integer> gradosPonderados = gradoPonderadoPersonajes();
    	
    	int suma = gradosPonderados.values().stream().reduce(0,(x,y)->x+y);
    	double media = suma/gradosPonderados.size();
    	System.out.println(media);
    	
    	Set<String> nombres = gradosPonderados.keySet();
    	Map<String,Integer> relevantes = new HashMap<String,Integer>();
    	int aux;
    	for(String n: nombres) {
    		aux = gradosPonderados.get(n);
    		if(aux > media) {
    			relevantes.put(n, aux);
    		}
    	}
    	
    	return relevantes;
    }
    /**
     * Tester de la clase GrafoGOT
     * @param args No se deben pasar argumentos a esta funcion, aunque si se pasan argumentos simplemente no seran
     * utilizados
     * @throws AristaInvalidaException Se ha intentado acceder a un arista que no existe
     * @throws VerticeIdException Se ha intentado crear un vertice con un ID que ya tiene otro vertice
     * @throws IOException Error con la apertura de los ficheros
     */
    public static void main(String[] args) throws AristaInvalidaException, VerticeIdException, IOException{
        GrafoGOT grafo = new GrafoGOT("vertices.csv","arcos.csv");
        System.out.println("\nResultado de llamar a casas():");
        System.out.println(grafo.casas());
        System.out.println("\nResultado de llamar a miembrosCasa(null):");
        System.out.println(grafo.miembrosCasa("null"));
        System.out.println("\nResultado de llamar a gradoPersonajes():");
        System.out.println(grafo.gradoPersonajes());
        System.out.println("\nResultado de llamar a gradoPonderadoPersonajes():");
        System.out.println(grafo.gradoPonderadoPersonajes());
        System.out.println("\nResultado de llamar a personajesRelevantes():");
        System.out.println(grafo.personajesRelevantes());
    }
}