package grafos;

import java.util.*;

/**
 * En esta clase definiremos un tipo de grafo; el grafo dirigido. En este tipo de grafo,
 * una arista va en una cierta direccion de un vertice a otro (es decir, es un grafo estandar)
 * @author David Cabornero y Alejandro Santorum
 *
 * @param <T> Tipo de dato que guarda cada vertice
 */
public class GrafoDirigido<T> extends Grafo<T>{
    
    public void addArco(Vertice<T> v1, Vertice<T> v2, double peso){
        v1.addAristaOut(v2, peso);
        v2.addAristaIn(v1, peso);
        incrementarAristas();
    }
}