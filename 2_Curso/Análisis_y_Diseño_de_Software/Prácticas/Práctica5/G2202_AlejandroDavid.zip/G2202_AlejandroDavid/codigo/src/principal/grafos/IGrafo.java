package grafos;

import java.util.*;
/**
 * Interfaz que permite determinar los metodos que deben incluir todas las clases Grafo
 * @author David Cabornero y Alejandro Santorum
 *
 * @param <T> Tipo de dato que albergan los vertices.
 */
public interface IGrafo<T> {
	/**
     * Metodo utilizado para anadir un vertice al grafo, sabiendo el dato que va a guardar el vertice
     * @param datos Datos guardados en el vertice
     * @return El vertice guardado
     * @throws VerticeIdException Se ha intentado introducir un vertice con un ID que ya estaba en el grafo
     */
	public Vertice<T> addVertice(T datos) throws VerticeIdException;
	/**
     * Getter que devuelve la lista de vertices del grafo
     * @return Lista de vertices del grafo
     */
	public List<Vertice<T>> getVertices(); 
	/**
     * Getter que devuelve el numero de vertices del grafo
     * @return Numero de vertices del grafo
     */
	public int getNumVertices();
	/**
     * Metodo usado para anadir un arista entre dos vertices al grafo
     * @param v1 Vertice del que sale la arista
     * @param v2 Vertice al que llega la arista
     * @param peso Peso de la arista
     */
	public abstract void addArco(Vertice<T> v1, Vertice<T> v2, double peso);
	/**
     * Metodo que indica si existe una arista entre dos vertices en el grafo
     * @param v1 Vertice del que queremos comprobar que sale una arista
     * @param v2 Vertice del que queremos comprobar que llega una arista
     * @return True si existe una arista, False en caso contrario
     */
	public boolean existeArco(Vertice<T> v1, Vertice<T>v2); 
	/**
     * Getter que devuelve en numero de arcos existentes en el grafo
     * @return Numero de arcos existentes
     */
	public int getNumArcos();
	/**
     * Metodo que devuelve el peso de cierta arista
     * @param v1 Vertice del que sale la arista
     * @param v2 Vertice al que llega la arista
     * @return Peso de la arista
     * @throws AristaInvalidaException La arista en cuestion no existe
     */
	public abstract Double getPesoDe(Vertice<T> v1, Vertice<T> v2) throws AristaInvalidaException; 
	/**
     * Metodo que nos devuelve la lista de vertices a los que esta conectado cierto vertice mediante
     * aristas
     * @param v Vertice del que queremos saber cuales son sus vertices vecinos
     * @return Lista de vertices vecinos
     */
	public abstract List<Vertice<T>> getVecinosDe(Vertice<T> v); 
	/**
     *  Este toString devuelve toda la informacion relevante del grafo. Define cada vertice del grafo, y a la vez que
     *  lo define explica con que vertices esta conectado.                                                          
     */
	public String toString();
}
