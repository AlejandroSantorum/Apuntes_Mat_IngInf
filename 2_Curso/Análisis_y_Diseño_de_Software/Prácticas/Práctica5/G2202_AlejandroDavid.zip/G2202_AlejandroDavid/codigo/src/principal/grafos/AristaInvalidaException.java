package grafos;


/**
 * En esta clase reside una excepcion que sera lanzada cuando nos intentemos referir a una arista que no existe
 * @author David Cabornero y Alejandro Santorum
 *	
 */
public class AristaInvalidaException extends Exception{
	
	/**
	 * Constructor of the exception AristaInvalidaException
	 * @param m Message sent to the console if the exception is thrown
	 */
	public AristaInvalidaException(String m) {
		super(m);
	}

}