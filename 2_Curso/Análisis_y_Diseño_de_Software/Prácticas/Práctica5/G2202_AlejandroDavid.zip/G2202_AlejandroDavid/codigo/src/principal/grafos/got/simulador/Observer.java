package grafos.got.simulador;

/**
 * Clase abstracta del patron de diseno observador.
 * @author David Cabornero y Alejandro Santorum
 *
 */
public abstract class Observer {
	protected Subject sujeto;
	
	/**
	 * Constructor de la clase Observer
	 * @param s Simulador al que esta 'observando' el observer
	 */
	public Observer(Subject s) {
		this.sujeto = s;
		sujeto.anadir(this);
	}
	
	/**
	 * Esta funcion sera llamada cada vez que el observador pueda necesitar ser actualizado. Para ello, 
	 * leeremos la informacion que tiene en ese momento el simulador y, si fuera necesario, nuestro observador anadira
	 * esa informacion a la que ya tiene.
	 */
	public abstract void actualizar();
}
