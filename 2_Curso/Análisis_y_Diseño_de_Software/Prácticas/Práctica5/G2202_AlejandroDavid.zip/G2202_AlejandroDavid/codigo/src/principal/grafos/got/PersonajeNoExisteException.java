package grafos.got;


/**
 * Excepcion lanzada cuando queremos acceder a datos de un personaje que no existe.
 * @author David Cabornero y Alejandro Santorum
 *
 */
public class PersonajeNoExisteException extends Exception{
	
	/**
	 * Constructor of the exception PersonajeNoExisteException
	 * @param m Message sent to the console if the exception is thrown
	 */
	public PersonajeNoExisteException(String m) {
		super(m);
	}

}