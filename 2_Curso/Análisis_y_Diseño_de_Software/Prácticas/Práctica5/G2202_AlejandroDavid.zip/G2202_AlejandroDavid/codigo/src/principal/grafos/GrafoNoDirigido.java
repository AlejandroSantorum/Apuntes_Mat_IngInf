package grafos;

import java.util.*;
/**
 * Esta clase implementara grafos dirigidos, es decir, grafos cuyas aristas no tienen direccion, o mejor dicho,
 * tienen las dos direcciones con el mismo peso.
 * @author David Cabornero y Alejandro Santorum
 *
 * @param <T>
 */
public class GrafoNoDirigido<T> extends Grafo<T>{
    /**
     * @param v1 Primer vertice (da igual el orden)
     * @param v2 Segundo vertice
     */
    public void addArco(Vertice<T> v1, Vertice<T> v2, double peso){
        v1.addAristaOut(v2, peso);
        v1.addAristaIn(v2, peso);
        v2.addAristaOut(v1, peso);
        v2.addAristaIn(v1, peso);
        incrementarAristas();
    }
}