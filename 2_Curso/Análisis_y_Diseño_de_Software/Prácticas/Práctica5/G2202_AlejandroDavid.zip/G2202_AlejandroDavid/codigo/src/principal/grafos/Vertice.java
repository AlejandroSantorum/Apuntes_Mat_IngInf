package grafos;

import java.util.*;
/**
 * Esta clase nos permite trabajar con los vertices de los datos, que guardan un tipo de dato generico.
 * @author David Cabornero y Alejandro Santorum
 *
 * @param <T> Tipo de dato generico que se guarda en el vertice
 */
public class Vertice<T>{
    private int id; // identificador del vertice dentro del grafo
    private T datos; // datos almacenados en el vertice
    private Map<Vertice<T>, Double> conexionesOut;
    private Map<Vertice<T>, Double> conexionesIn;;
    
    /**
     * Constructor de la clase Vertice
     * @param id ID del vertice
     * @param datos Datos que se guardaran en el vertice
     */
    public Vertice(int id, T datos){
        this.id = id;
        this.datos = datos;
        conexionesOut = new HashMap<Vertice<T>, Double>();
        conexionesIn = new HashMap<Vertice<T>, Double>();
    }
    /**
     * Getter que permite obtener el ID del vertice
     * @return ID del vertice
     */
    public int getId(){
        return id;
    }
    /**
     * Getter que permite obtener los datos que guarda el vertice
     * @return Datos del vertice
     */
    public T getDatos(){
        return datos;
    }
    /**
     * Getter que permite obtener las conexiones que llegan al vertice
     * @return Mapa que tiene de key cada vertice al que esta conectado el nuestro, y el valor asociado es el 
     * peso de esa arista
     */
    public Map<Vertice<T>, Double> getConexionesOut(){
        return conexionesOut;
    }
    /**
     * Getter que permite obtener las conexiones que salen del vertice
     * @return Mapa que tiene de key cada vertice al que esta conectado el nuestro, y el valor asociado es el 
     * peso de esa arista
     */
    public Map<Vertice<T>, Double> getConexionesIn(){
        return conexionesIn;
    }
    
    /**
     * Este toString informa del id y los datos del vertice.
     */
    public String toString(){
        String aux;
        aux = "Vertice con ID = "+id+" y con dato = "+datos;
        return aux;
    }
    /**
     * Este 'toString' devuelve el toString de todos los vertices que estan conectados al nuestro
     * @return
     */
    public String imprimirConexiones(){
        String aux;
        Set<Vertice<T>> out = conexionesOut.keySet();
        Set<Vertice<T>> in = conexionesIn.keySet();
        aux = "-Conectado a:\n";
        for(Vertice<T> v: out){
            aux += "\t--> "+v+"\n";
        }
        aux += "-Conectado desde:\n";
        for(Vertice<T> v: in){
            aux += "\t--> "+v+"\n";
        }
        return aux;
        
    }
    
    /**
     * Muestra si dos vertices son el mismo
     * @param v Vertice con el que queremos comparar al nuestro
     * @return True si son el mismo, False en caso contrario
     */
    public Boolean equals(Vertice<T> v){
        if(this.id == v.id){
            return true;
        }
        return false;
    }
    /**
     * Permite anadir un arista saliente
     * @param v Vertice al que llega la arista
     * @param peso Peso de la arista
     */
    public void addAristaOut(Vertice<T> v, Double peso){
        conexionesOut.put(v, peso);
    }
    /**
     * Permite anadir un arista entrante
     * @param v Vertice del que viene la arista
     * @param peso Peso de la arista
     */
    public void addAristaIn(Vertice<T> v, Double peso){
        conexionesIn.put(v, peso);
    }
    
    /**
     * Permite saber si existe una arista que sale de nuestro vertice y llega a otro
     * @param v El otro vertice con el que queremos combrobar si existe una arista
     * @return True si existe, False si no
     */
    public Boolean existeAristaOut(Vertice<T> v){
        return conexionesOut.containsKey(v);
    }
    /**
     * Permite saber si existe una arista que salga de otro vertice y llegue al nuestro
     * @param v El otro vertice con el que queremos combrobar si existe una arista
     * @return True si existe, False si no
     */
    public Boolean existeAristaIn(Vertice<T> v){
        return conexionesIn.containsKey(v);
    }
    
    /**
     * Permite obtener el peso de la arista que sale de nuestro vertice y llega al vertice v
     * @param v Vertice al que llega la arista
     * @return Peso de la arista
     * @throws AristaInvalidaException Dicha arista no existe
     */
    public Double getPesoArista(Vertice<T> v) throws AristaInvalidaException{
        if(!conexionesOut.containsKey(v)){
            throw new AristaInvalidaException("No existe un arco entre el vertice "+this.id+" y el vertice "+v.id);
        }
        else{
            return conexionesOut.get(v);
        }
    }
}