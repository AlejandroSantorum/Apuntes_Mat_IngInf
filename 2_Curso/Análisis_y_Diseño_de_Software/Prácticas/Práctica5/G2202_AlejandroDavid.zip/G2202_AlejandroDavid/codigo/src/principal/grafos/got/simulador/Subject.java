package grafos.got.simulador;

import java.util.*;
/**
 * Clase abstracta que nos permitira crear el simulador del patron de diseno Observer, ademas de que en
 * esta clase podremos guardar los observers.
 * @author David Cabornero y Alejandro Santorum
 *
 */
public abstract class Subject {
	protected List<Observer> observers;
	/**
	 * Constructor de la clase Subject
	 */
	public Subject() {
		this.observers = new ArrayList<Observer>();
	}
	/**
	 * Metodo que permite anadir un nuevo observer al simulador
	 * @param o El observer ya creado
	 */
	public void anadir(Observer o) {
		observers.add(o);
	}
	/**
	 * Metodo que permite borrar un observer del simulador
	 * @param o Observer del simulador
	 */
	public void borrar(Observer o) {
		observers.remove(o);
	}
	/**
	 * Metodo que permite informar a todos los observadores de que ha sucedido un evento en el simulador,
	 * y deben actualizarse
	 */
	public void notificar() {
		Iterator<Observer> it;
		it = observers.iterator();
		while (it.hasNext()) {
			it.next().actualizar();
		}
	}
}
