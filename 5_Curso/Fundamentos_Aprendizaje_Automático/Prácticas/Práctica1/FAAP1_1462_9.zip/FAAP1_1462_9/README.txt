Autores:
	· Alejandro Santorum Varela - alejandro.santorum@estudiante.uam.es
	· José Manuel Chacón Aguilera - josem.chacon@estudiante.uam.es
Práctica 1 - Fundamentos Aprendizaje Automático
Fecha: 24 octubre 2020
Grupo: 1462
Pareja: 9


Observación: Si se deseasen ejecutar las instrucciones del notebook se necesitan
Instalar ciertos paquetes de python3 no estándar:
· numpy (cálculos numérico y estructuras de datos)
· Scikit-learn (machine learning)
· Matplotlib (gráficas)
· tabulate (tablas)
Entre otros.