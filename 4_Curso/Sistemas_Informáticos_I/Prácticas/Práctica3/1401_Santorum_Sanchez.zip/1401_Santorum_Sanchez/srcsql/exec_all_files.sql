\i actualiza.sql;
\i setPrice.sql;
\i setOrderAmount.sql;
select setOrderAmount();
\i getTopVentas.sql;
\i getTopMonths.sql;
\i updOrders.sql;
\i updInventory.sql;
