#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tree.h"

typedef struct _NodeBT {
    void* info;
    struct _NodeBT *left;
    struct _NodeBT *right;
} NodeBT;

struct _Tree {
    NodeBT *root;
    destroy_elementtree_function_type   destroy_element_function;
    copy_elementtree_function_type      copy_element_function;
    print_elementtree_function_type     print_element_function;
    cmp_elementtree_function_type     cmp_element_function;
};


NodeBT* nodeBT_ini(){
    NodeBT *n=NULL;
    
    n = (NodeBT *) malloc(sizeof(NodeBT));
    if(n == NULL){
        return NULL;
    }
    
    n->info = NULL;
    n->left = NULL;
    n->right = NULL;
    
    return n;
}

void nodeBT_destroy(NodeBT *n, Tree *t){
    if(n == NULL || t == NULL){
        return;
    }
    
    if(n->info != NULL){
        t->destroy_element_function(n->info);
    }
    
    free(n);
}


Tree* tree_ini(destroy_elementtree_function_type f1, copy_elementtree_function_type f2, print_elementtree_function_type f3, cmp_elementtree_function_type f4){
    Tree *t=NULL;
    
    t = (Tree *) malloc(sizeof(Tree));
    if(t == NULL){
        return NULL;
    }
    
    t->destroy_element_function = f1;
    t->copy_element_function = f2;
    t->print_element_function = f3;
    t->cmp_element_function = f4;
    
    t->root = NULL;
    
    return t;
}


void tree_destroy_rec(NodeBT *n, Tree *t){
    if(n == NULL){
        return;
    }
    
    tree_destroy_rec(n->left, t);
    tree_destroy_rec(n->right, t);
    nodeBT_destroy(n, t);
    return;
}
void tree_destroy (Tree *t){
    if(t == NULL){
        return ;
    }
    
    if(t->root == NULL){
        free(t);
        return;
    }
    
    tree_destroy_rec(t->root, t);
    
    free(t);
}


Status tree_insert_rec(NodeBT **n, void *ele, Tree *t){
    int cmp;
    
    if(n == NULL){
        return ERROR;
    }
    
    if((*n) == NULL){
        *n = nodeBT_ini();
        if((*n)==NULL){
            return ERROR;
        }
        (*n)->info = t->copy_element_function(ele);
        if((*n)->info == NULL){
            nodeBT_destroy(*n, t);
            *n = NULL;
            return ERROR;
        }
        return OK;
    }
    
    cmp = t->cmp_element_function(ele, (*n)->info);
    
    if(cmp < 0){
        return tree_insert_rec(&((*n)->left), ele, t);
    }
    
    if(cmp > 0){
        return tree_insert_rec(&((*n)->right), ele, t);
    }
    
    if(cmp == 0){
        fprintf(stdout, "The element is already in the tree.\n");
        return OK;
    }
    return OK;
}
Status tree_insert(Tree *t, void *ele){
    if(t == NULL || ele == NULL){
        return ERROR;
    }
    
    return tree_insert_rec(&(t->root), ele, t);
}



Bool tree_find_rec(NodeBT *n, void *ele, Tree *t){
    int cmp;
    
    if(n == NULL){
        return FALSE;
    }
    
    cmp = t->cmp_element_function(ele, n->info);
    
    if(cmp < 0){
        return tree_find_rec(n->left, ele, t);
    }
    
    if(cmp > 0){
        return tree_find_rec(n->right, ele, t);
    }
    
    return TRUE;
}
Bool tree_find(Tree *t, void *ele){
    if(t == NULL || ele == NULL){
        return ERROR;
    }
    
    return tree_find_rec(t->root, ele, t);
}



Bool tree_isEmpty(const Tree *t){
    if(t == NULL){
        fprintf(stdout, "The tree doesn't exist.\n");
        return FALSE;
    }
    
    if(t->root == NULL){
        return TRUE;
    }
    
    return FALSE;
}


int tree_depth_rec(NodeBT *n){
    int i, j;
    
    if(n == NULL){
        return 0;
    }
    
    i = tree_depth_rec(n->left);
    j = tree_depth_rec(n->right);
    
    if(i>=j){
        return i+1;
    }
    else{
        return j+1;
    }
}
int tree_depth(const Tree *t){
    if(t == NULL){
        fprintf(stdout, "The tree doesn't exist.\n");
        return -2;
    }
    
    if(t->root == NULL){
        return -1;
    }
    
    return tree_depth_rec(t->root)-1;
}


int tree_numNodes_rec(NodeBT *n){
    int i, j;
    
    if(n == NULL){
        return 0;
    }
    
    i = tree_numNodes_rec(n->left);
    j = tree_numNodes_rec(n->right);
    
    return i+j+1;
}
int tree_numNodes(const Tree *t){
    if(t == NULL){
        fprintf(stdout, "The tree doesn't exist.\n");
        return -1;
    }
    
    if(t->root == NULL){
        return 0;
    }
    
    return tree_numNodes_rec(t->root);
}

/*FUNCIONES DE ARBOLES DE EXPRESION*/
Status tree_preOrder_rec(FILE *f, NodeBT *n, Tree *t){
    t->print_element_function(f, n->info);
    
    if(n->left != NULL){
        tree_preOrder_rec(f, n->left, t);
    }
    if(n->right != NULL){
        tree_preOrder_rec(f, n->right, t);
    }
    
    return OK;
}
Status  tree_preOrder(FILE *f, Tree *t){
    if(f == NULL || t == NULL){
        return ERROR;
    }
    if (t->root == NULL){
        fprintf(f, "\n");
        return OK;
    }
    
    return tree_preOrder_rec(f, t->root, t);
}


Status tree_inOrder_rec(FILE *f, NodeBT *n, Tree *t){
    if(n->left != NULL){
        tree_inOrder_rec(f, n->left, t);
    }
    
    t->print_element_function(f, n->info);
    
    if(n->right != NULL){
        tree_inOrder_rec(f, n->right, t);
    }
    
    return OK;
}
Status  tree_inOrder(FILE *f, Tree *t){
    if(f == NULL || t == NULL){
        return ERROR;
    }
    if (t->root == NULL){
        fprintf(f, "\n");
        return OK;
    }
    
    return tree_inOrder_rec(f, t->root, t);
}


Status tree_postOrder_rec(FILE *f, NodeBT *n, Tree *t){
    if(n->left != NULL){
        tree_postOrder_rec(f, n->left, t);
    }
    if(n->right != NULL){
        tree_postOrder_rec(f, n->right, t);
    }
    
    t->print_element_function(f, n->info);
    
    return OK;
}
Status  tree_postOrder(FILE *f, Tree *t){
    if(f == NULL || t == NULL){
        return ERROR;
    }
    if (t->root == NULL){
        fprintf(f, "\n");
        return OK;
    }
    
    return tree_postOrder_rec(f, t->root, t);
}

/*OPCIONAL*/
Status tree_preOrderToList_rec(List*l, NodeBT *n){
    if(list_insertLast(l, n->info) == NULL){
        return ERROR;
    }
    
    if(n->left != NULL){
        tree_preOrderToList_rec(l, n->left);
    }
    if(n->right != NULL){
        tree_preOrderToList_rec(l, n->right);
    }
    
    return OK;
}
Status tree_preOrderToList(List*l, Tree *t){
    if(l == NULL || t == NULL){
        return ERROR;
    }
    
    if (t->root == NULL){
        return OK;
    }
    
    return tree_preOrderToList_rec(l, t->root);
}

Status tree_inOrderToList_rec(List*l, NodeBT *n){
    if(n->left != NULL){
        tree_inOrderToList_rec(l, n->left);
    }
    
    if(list_insertLast(l, n->info) == NULL){
        return ERROR;
    }
    
    if(n->right != NULL){
        tree_inOrderToList_rec(l, n->right);
    }
    
    return OK;
}
Status tree_inOrderToList(List*l, Tree *t){
    if(l == NULL || t == NULL){
        return ERROR;
    }
    
    if (t->root == NULL){
        return OK;
    }
    
    return tree_inOrderToList_rec(l, t->root);
}

Status tree_postOrderToList_rec(List*l, NodeBT *n){
    if(n->left != NULL){
        tree_postOrderToList_rec(l, n->left);
    }
    if(n->right != NULL){
        tree_postOrderToList_rec(l, n->right);
    }
    
    if(list_insertLast(l, n->info) == NULL){
        return ERROR;
    }
    
    return OK;
}
Status tree_postOrderToList(List*l, Tree *t){
    if(l == NULL || t == NULL){
        return ERROR;
    }
    
    if (t->root == NULL){
        return OK;
    }
    
    return tree_postOrderToList_rec(l, t->root);
}