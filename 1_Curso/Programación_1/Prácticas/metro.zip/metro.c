/**
 * Modulo: metro.c
 *
 * Descripcion: contiene funciones de creacion, visualizacion y liberacion
 * de una red de metro cargada de un fichero de texto.
 *
 * Autor: Ivan Cantador, ivan.cantador@uam.es
 *
 * Version: 1.0
 * Fecha: 13/12/2016
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Definicion de valores constantes

#define OK 0
#define ERROR -1

#define MAX_NOMBRE 64

#define MAX_LINEAS_RED 16
#define MAX_ESTACIONES_LINEA 64
#define MAX_CORRESPONDENCIAS_ESTACION 16

// Declaracion de estructuras de datos

typedef struct {
    char nombre[MAX_NOMBRE];
    int correspondencias[MAX_CORRESPONDENCIAS_ESTACION];
    int numeroCorrespondencias;
} EstacionMetro;

typedef struct {
    int numero;
    EstacionMetro estaciones[MAX_ESTACIONES_LINEA];
    int numeroEstaciones;
} LineaMetro;

typedef struct {
    char ciudad[MAX_NOMBRE];
    LineaMetro lineas[MAX_LINEAS_RED];
    int numeroLineas;
} RedMetro;

// Definicion de funciones

/**
 * Funcion: metro_crear
 *
 * Descripcion: reserva memoria dinamica para una estructura RedMetro e inicializa
 * sus campos con los datos leidos de un fichero de texto pasado como argumento de
 * entdrada.
 *
 * Argumentos de entrada:
 * - nombreCiudad: nombre de la ciudad a la que pertenece la red de metro a crear
 * - pathFichero: ruta del fichero de texto con los datos de la red de metro a crear
 *
 * Retorno:
 * - Puntero a la estructura RedMetro creada; NULL en caso de argumentos de entrada
 *   incorrectos o fallo en la reserva de memoria o en la lectura de datos del fichero
 */
RedMetro *metro_crear(const char *nombreCiudad, const char *pathFichero) {
    RedMetro *red = NULL;
    FILE *fichero = NULL;
    int i, j, k;
    char cadena[256], *token = NULL;

    if ( nombreCiudad == NULL || pathFichero == NULL ) {
        return NULL;
    }

    red = (RedMetro *) malloc(sizeof(RedMetro));
    if ( red == NULL ) {
        return NULL;
    }
    strcpy(red->ciudad, nombreCiudad);

    // Abrimos el fichero
    fichero = fopen(pathFichero, "r");
    if ( fichero == NULL ) {
        free(red);
        return NULL;
    }

    // Leemos el numero de lineas de metro
    fgets(cadena, 256, fichero);
    red->numeroLineas = atoi(cadena);

    // Para cada linea de metro...
    for ( i = 0; i < red->numeroLineas; i++ ) {
        // Leemos el numero de estaciones
    	fgets(cadena, 256, fichero);

        token = strtok(cadena, "|");    // Nos posicionamos en el n�mero de estaciones

        token = strtok(NULL, "|");
        red->lineas[i].numeroEstaciones = atoi(token);

        red->lineas[i].numero = i + 1;

        // Leemos las estaciones
        for ( j = 0; j < red->lineas[i].numeroEstaciones; j++ ) {
            // Leemos el nombre de la j-esima estacion
            fgets(cadena, 256, fichero);
            token = strtok(cadena, "|");
            strcpy(red->lineas[i].estaciones[j].nombre, token);

            // Leemos las correspondencias la j-esima estacion
            red->lineas[i].estaciones[j].numeroCorrespondencias = 0;
            k = 0;
            while( (token = strtok(NULL, " ,\n")) != NULL ) {
                red->lineas[i].estaciones[j].numeroCorrespondencias++;
                red->lineas[i].estaciones[j].correspondencias[k] = atoi(token);
                k++;
            }
        }
    }

    fclose(fichero);

    return red;
}

/**
 * Funcion: metro_liberar
 *
 * Descripcion: libera la memoria reservada dinamicamente de una RedMetro pasada
 * como argumento de entrada.
 *
 * Argumentos de entrada:
 * - red: puntero al a la red a liberar
 *
 * Retorno:
 * - (nada)
 */
void metro_liberar(RedMetro *red) {
    if ( red != NULL ) {
        free(red);
    }
}

/**
 * Funcion: metro_visualizarLinea
 *
 * Descripcion: escribe por pantalla las estaciones de una linea en una red de metro
 * pasada como argumento de entrada.
 *
 * Argumentos de entrada:
 * - red: red de metro con las estaciones de la linea a visualizar
 * - linea: numero de la linea a visualizar
 *
 * Retorno:
 * - ERROR si alguno de los argumentos de entrada incorrectos; OK en caso contrario
 */
int metro_visualizarLinea(RedMetro *red, int linea) {
    int i, j;

    if ( red == NULL || linea <= 0 || linea > red->numeroLineas ) {
        return ERROR;
    }

    printf("Estaciones de la linea %d:\n", linea);

	// Por cada estacion de la linea...
	for ( i=0; i<red->lineas[linea-1].numeroEstaciones; i++ ) {
		// Imprimimos el nombre de la estacion
        printf("\t%s", red->lineas[linea-1].estaciones[i].nombre);

		// Si las tiene, imprimimos las correspondencias de la estacion
        if ( red->lineas[linea-1].estaciones[i].numeroCorrespondencias > 0 ) {
            printf("\t[");
            for ( j=0; j<red->lineas[linea-1].estaciones[i].numeroCorrespondencias; j++ ) {
                printf(" %d ", red->lineas[linea-1].estaciones[i].correspondencias[j]);
            }
            printf("]");
        }

        printf("\n");
    }

    return OK;
}

/**
 * Funcion: metro_visualizarCorrespondencias
 *
 * Descripcion: escribe por pantalla las lineas que son correspondencia de una
 * estacion de metro pasada como argumento de entrada.
 *
 * Argumentos de entrada:
 * - red: red de metro con las correspondencias de la estacion a visualizar
 * - linea: nombre de la estacion a visualizar
 *
 * Retorno:
 * - ERROR si alguno de los argumentos de entrada incorrectos; OK en caso contrario
 */
int metro_visualizarCorrespondencias(RedMetro *red, const char *estacion) {
	int i, j, k;

    if ( red == NULL || estacion == NULL  ) {
        return ERROR;
    }

	for ( i = 0; i < red->numeroLineas; i++ ) {
		for ( j = 0; j < red->lineas[i].numeroEstaciones; j++ ) {
			if ( strcmp(red->lineas[i].estaciones[j].nombre, estacion) == 0 ) {
				printf("Correspondencias de %s:\t[", estacion);

				printf(" %d", i+1);  // la propia linea de metro

				for ( k = 0; k < red->lineas[i].estaciones[j].numeroCorrespondencias; k++ ) {
					printf(" %d ", red->lineas[i].estaciones[j].correspondencias[k]);  // las lineas que son correspondencia
				}

				printf("]\n");

				return OK;
			}
		}  // for j
	}  // for i

	return ERROR; // estacion no encontrada
}

/**
 * Funcion: main
 *
 * Descripcion: programa de prueba de las funciones de la estructura RedMetro.
 */
int main(void) {
    RedMetro *metro = NULL;
    char rutaFichero[] = "metro-madrid.txt";
	char nombreEstacion[MAX_NOMBRE], cadena[32];
    int numeroLinea, salir, opcion, ret;

    metro = metro_crear("Madrid", rutaFichero);
    if ( metro == NULL ) {
        printf("Error: la red de metro no se pudo crear a partir del fichero:\n%s\n", rutaFichero);
        return ERROR;
    }
    printf("Red de metro de %s creada con %d l�neas.\n", metro->ciudad, metro->numeroLineas);

    salir = 0;
    while ( salir == 0 ) {
        printf("\n");
        printf("1. Visualizar las estaciones de una linea de metro.\n");
        printf("2. Visualizar las correspondencias de una estacion de metro.\n");
        printf("3. Salir.\n\n");
        printf("Introduzca una opcion [1-3]: ");
        gets(cadena);
        opcion = atoi(cadena);

        switch ( opcion ) {
            case 1:
                printf("Introduzca el numero de linea de metro a visualizar: ");
                gets(cadena);
                numeroLinea = atoi(cadena);
                ret = metro_visualizarLinea(metro, numeroLinea);
                if ( ret == ERROR ) {
                    printf("Error: numero de linea incorrecto.\n");
                }
                break;
			case 2:
                printf("Introduzca el nombre de la estacion a visualizar: ");
				gets(nombreEstacion);
				ret = metro_visualizarCorrespondencias(metro, nombreEstacion);
				if ( ret == ERROR ) {
                    printf("Error: estacion no encontrada.\n");
                }
				break;
            case 3:
                salir = 1;
                break;
            default:
                printf("Error: opcion introducida incorrecta.\n");
        }
    } // while

    metro_liberar(metro);

    return OK;
}
