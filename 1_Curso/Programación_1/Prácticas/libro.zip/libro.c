/**
 * Modulo: libro.c
 * 
 * Descripcion: contiene la definicion de las funciones primitivas 
 * de la estructura Libro.
 *
 * Autor: Ivan Cantador, ivan.cantador@uam.es
 *
 * Version: 1.0
 * Fecha: 10/12/2016
 */
 
#include <stdio.h>
#include <stdlib.h>
#include "libro.h"
#include "autor.h"

// Definicion de funciones primitivas asociadas a Libro

/**
 * Funcion: libroCrear
 * 
 * Descripcion: reserva memoria dinamica para una estructura Libro e inicializa 
 * sus campos con los datos pasados como argumentos de entdrada.
 * 
 * Argumentos de entrada:
 * - tituloLibro: titulo del libro
 * - anioLibro: anio de publicacion del libro
 * - nombreAutor: nombre del autor del libro
 * - apellidosAutor: apellidos del autor del libro
 * 
 * Retorno:
 * - Puntero a la estructura Libro creada; NULL en caso de argumentos de entrada 
 *   incorrectos o fallo en la reserva de memoria
 */
Libro *libroCrear(char *tituloLibro, int anioLibro, char *nombreAutor, char *apellidosAutor) {
    Libro *pl = NULL;

    // Comprobamos argumentos de entrada
    if (!tituloLibro || anioLibro <= 0 || !nombreAutor || !apellidosAutor) {
        return NULL;
    }

    // Reservamos memoria para la estructura Libro
    // La reserva de memoria de una estructura se hace de mas a menos, es decir
    // desde la propia estructura hasta los campos mas internos
    pl = (Libro *) malloc(sizeof(Libro));
    if (!pl) {
        return NULL;
    }
	pl->titulo =  NULL;
	pl->autor = NULL;

    // Reservamos memoria para los campos de la estructura Libro
    // Ojo: con cadenas de caracteres reservamos memoria para un caracter 
    // adicional en el que guardaremos el '\0'
    pl->titulo = (char *) malloc((1 + strlen(tituloLibro)) * sizeof(char));
    if (!pl->titulo) {
        libroLiberar(pl);
        return NULL;
    }

    pl->autor = autorCrear(nombreAutor, apellidosAutor);
    if (!pl->autor) {
        libroLiberar(pl);
        return NULL;
    }

    // Una vez reservada su memoria, incializamos todos los campos del libro
    strcpy(pl->titulo, tituloLibro);
    pl->anio = anioLibro;

    return pl;
}

/**
 * Funcion: libroLiberar
 * 
 * Descripcion: libera la memoria reservada dinamicamente de un Libro pasado
 * como argumento de entrada.
 * 
 * Argumentos de entrada:
 * - pl: puntero al libro a liberar
 * 
 * Retorno:
 * - (nada)
 */
void libroLiberar(Libro *pl) {
    // La liberacion de memoria de una estructura se hace de menos a mas, es decir
    // desde los campos mas internos hasta la propia estructura
    if (pl) {
        if (pl->titulo) {
            free(pl->titulo);
        }
        autorLiberar(pl->autor);

        free(pl); // Liberamos pl despues de liberar titulo y autor
    }
}
