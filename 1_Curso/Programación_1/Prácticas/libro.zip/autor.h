/**
 * Modulo: autor.h
 * 
 * Descripcion: contiene la definicion de la estructura Autor y la
 * declaracion de sus funciones primitivas.
 *
 * Autor: Ivan Cantador, ivan.cantador@uam.es
 *
 * Version: 1.0
 * Fecha: 10/12/2016
 */
 
#ifndef AUTOR_H
#define AUTOR_H

// Definicion de la estructura de datos Autor

typedef struct {
    char *nombre;
    char *apellidos;
} Autor;

// Declaracion de funciones primitivas asociadas a Autor

/**
 * Funcion: autorCrear
 * 
 * Descripcion: reserva memoria para una estructura Autor e inicializa 
 * sus campos con los datos pasados como argumentos de entdrada.
 * 
 * Argumentos de entrada:
 * - nombreAutor: nombre del autor del libro
 * - apellidosAutor: apellidos del autor del libro
 * 
 * Retorno:
 * - Puntero a la estructura Autor creada; NULL en caso de argumentos de entrada 
 *   incorrectos o fallo en la reserva de memoria
 */
Autor *autorCrear(char *nombreAutor, char *apellidosAutor);

/**
 * Funcion: autorLiberar
 * 
 * Descripcion: libera la memoria reservada dinamicamente de un Autor pasado
 * como argumento de entrada.
 * 
 * Argumentos de entrada:
 * - pa: puntero al autor a liberar
 * 
 * Retorno:
 * - (nada)
 */
void autorLiberar(Autor *pa);

#endif
