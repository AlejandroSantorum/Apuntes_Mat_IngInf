/**
 * Modulo: main.c
 * 
 * Descripcion: programa de prueba de la estructura de datos Libro.
 *
 * Autor: Ivan Cantador, ivan.cantador@uam.es
 *
 * Version: 1.0
 * Fecha: 10/12/2016
 */
 
#include <stdio.h>
#include "libro.h"

void main() {
    Libro *libro = NULL;
    char nombreAutor[32], apellidosAutor[64], tituloLibro[64];
    int anioLibro;

    printf("Nombre del autor: ");
    gets(nombreAutor);
    printf("Apellidos del autor: ");
    gets(apellidosAutor);
    printf("Titulo del libro: ");
    gets(tituloLibro);
    printf("Anio de publicacion del libro: ");
    scanf("%d", &anioLibro);

    libro = libroCrear(tituloLibro, anioLibro, nombreAutor, apellidosAutor);

    if (libro) {
        printf("%s (%d), de %s %s.\n", libro->titulo, libro->anio, libro->autor->nombre, libro->autor->apellidos);
        libroLiberar(libro);
    }
}
