/**
 * Modulo: libro.h
 * 
 * Descripcion: contiene la definicion de la estructura Libro y la
 * declaracion de sus funciones primitivas.
 *
 * Autor: Ivan Cantador, ivan.cantador@uam.es
 *
 * Version: 1.0
 * Fecha: 10/12/2016
 */
 
#ifndef LIBRO_H
#define LIBRO_H

// Definicion de la estructura de datos Autor

typedef struct {
    char *titulo;
    Autor *autor;
    int anio;
} Libro;

// Declaracion de funciones primitivas asociadas a Libro

/**
 * Funcion: libroCrear
 * 
 * Descripcion: reserva memoria dinamica para una estructura Libro e inicializa 
 * sus campos con los datos pasados como argumentos de entdrada.
 * 
 * Argumentos de entrada:
 * - tituloLibro: titulo del libro
 * - anioLibro: anio de publicacion del libro
 * - nombreAutor: nombre del autor del libro
 * - apellidosAutor: apellidos del autor del libro
 * 
 * Retorno:
 * - Puntero a la estructura Libro creada; NULL en caso de argumentos de entrada 
 *   incorrectos o fallo en la reserva de memoria
 */
Libro *libroCrear(char *tituloLibro, int anioLibro, char *nombreAutor, char *apellidosAutor);

/**
 * Funcion: libroLiberar
 * 
 * Descripcion: libera la memoria reservada dinamicamente de un Libro pasado
 * como argumento de entrada.
 * 
 * Argumentos de entrada:
 * - pl: puntero al libro a liberar
 * 
 * Retorno:
 * - (nada)
 */
void libroLiberar(Libro *pl);

#endif
