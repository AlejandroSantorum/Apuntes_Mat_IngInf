/**
 * Modulo: autor.c
 * 
 * Descripcion: contiene la definicion de las funciones primitivas 
 * de la estructura Autor.
 *
 * Autor: Ivan Cantador, ivan.cantador@uam.es
 *
 * Version: 1.0
 * Fecha: 10/12/2016
 */
 
#include <stdio.h>
#include <stdlib.h>
#include "autor.h"

// Definicion de funciones primitivas asociadas a Libro


/**
 * Funcion: autorCrear
 * 
 * Descripcion: reserva memoria para una estructura Autor e inicializa 
 * sus campos con los datos pasados como argumentos de entdrada.
 * 
 * Argumentos de entrada:
 * - nombreAutor: nombre del autor del libro
 * - apellidosAutor: apellidos del autor del libro
 * 
 * Retorno:
 * - Puntero a la estructura Autor creada; NULL en caso de argumentos de entrada 
 *   incorrectos o fallo en la reserva de memoria
 */
Autor *autorCrear(char *nombreAutor, char *apellidosAutor) {
    Autor *pa = NULL;

    // Comprobamos argumentos de entrada
    if (!nombreAutor || !apellidosAutor) {
        return NULL;
    }

    // Reservamos memoria para la estructura Autor
    // La reserva de memoria de una estructura se hace de mas a menos, es decir
    // desde la propia estructura hasta los campos mas internos
    pa = (Autor *) malloc(sizeof(Autor));
    if (!pa) {
        return NULL;
    }
	pa->nombre = NULL;
	pa->apellidos = NULL;

    // Reservamos memoria para los campos de la estructura Autor
    // Ojo: con cadenas de caracteres reservamos memoria para un caracter 
    // adicional en el que guardaremos el '\0'
    pa->nombre = (char *) malloc((1 + strlen(nombreAutor)) * sizeof(char));
    if (!pa->nombre) {
        autorLiberar(pa);
        return NULL;
    }

    pa->apellidos = (char *) malloc((1 + strlen(apellidosAutor)) * sizeof(char));
    if (!pa->apellidos) {
        autorLiberar(pa);
        return NULL;
    }

    // Una vez reservada su memoria, incializamos todos los campos del autor
    strcpy(pa->nombre, nombreAutor);
    strcpy(pa->apellidos, apellidosAutor);

    return pa;
}

/**
 * Funcion: autorLiberar
 * 
 * Descripcion: libera la memoria reservada dinamicamente de un Autor pasado
 * como argumento de entrada.
 * 
 * Argumentos de entrada:
 * - pa: puntero al autor a liberar
 * 
 * Retorno:
 * - (nada)
 */
void autorLiberar(Autor *pa) {
    // La liberacion de memoria de una estructura se hace de menos a mas, es decir
    // desde los campos mas internos hasta la propia estructura
    if (pa) {
        if (pa->nombre) {
            free(pa->nombre);
        }
		if (pa->apellidos) {
            free(pa->apellidos);
        }
		free(pa); // Liberamos pa despues de liberar nombre y apellidos
    }
}
